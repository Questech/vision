<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">  
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!--/ No cache -->
    <meta http-equiv="cache-control" content="max-age=0" />
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="expires" content="0" />
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
    <meta http-equiv="pragma" content="no-cache" />

    <title>Vision| Group</title>
    <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>assets/css/main.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>assets/dashboard/css/AdminLTE.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>assets/dashboard/css/skins/_all-skins.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>assets/parsley/parsley.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>assets/datepicker/datepicker3.min.css" rel="stylesheet" type="text/css">


    <script type="text/javascript" src="<?php echo base_url(); ?>assets/jquery/jquery-2.1.1.min.js"></script>


  <!--- Data Tables -->
    <script src="jquery-1.11.2.js"></script>
    <script src="<?php echo base_url(); ?>assets/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/datatables/dataTables.tableTools.min.js"> </script>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/datatables/jquery.dataTables.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/datatables/dataTables.tableTools.css" />

    <!-- datatable-->
        <script type="text/javascript">
            $(document).ready(function () {
                var table = $('#datatable').dataTable();
                var tableTools = new $.fn.dataTable.TableTools(table, {
                    'aButtons': [
                        {
                            'sExtends': 'xls',
                            'sButtonText': 'Save to Excel',
                            'sFileName': 'Data.xls'
                        },
                        {
                            'sExtends': 'print',
                            'bShowAll': true,
                        },
                        {
                            'sExtends': 'pdf',
                            'bFooter': false
                        },
                        'copy',
                        'csv'
                    ],
                    'sSwfPath': '//cdn.datatables.net/tabletools/2.2.4/swf/copy_csv_xls_pdf.swf'
                });
                $(tableTools.fnContainer()).insertBefore('#datatable_wrapper');
            });
        </script>

</head>
  
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

      <!-- Main Header -->
      <header class="main-header">

        <!-- Logo -->
        <a href="#" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>V</b>G</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>Vision</b>Group</span>
        </a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
             
                 
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <!--<a href="#" class="btn btn-default btn-flat">Profile</a>-->
                    </div>
                    <div class="pull-right">
                      <a href="membership/logout" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
               
              </li>
              <!-- Control Sidebar Toggle Button -->
              <li>
                <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- Sidebar user panel (optional) -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url() ;?>assets/img/avatar5.png" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p>Vision Admin</p>
              <!-- Status -->
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>

          <!-- Sidebar Menu -->
          <ul class="sidebar-menu">
            <li class="header">MENU</li>
            


           <!--  <li><a href="<?php echo site_url('dashboard'); ?>"><i class="fa fa-windows"></i> Dashboard</a></li> -->
            <li><a href="<?php echo site_url('montly_contribution'); ?>"><i class="fa fa-windows"></i> Monthly Contributions</a></li>
            <li><a href="<?php echo site_url('add_loan'); ?>"><i class="fa fa-windows"></i> Award Loan</a></li>
            <li><a href="<?php echo site_url('loans'); ?>"><i class="fa fa-windows"></i> Loan Payments</a></li>
            <li><a href="<?php echo site_url('fines'); ?>"><i class="fa fa-windows"></i> Fines</a></li>
            <li><a href="<?php echo site_url('loan_type'); ?>"><i class="fa fa-windows"></i> Loan Types</a></li>
            <li><a href="<?php echo site_url('users'); ?>"><i class="fa fa-windows"></i> Members</a></li>

            <!--  <li><a href="<?php echo site_url('builder/tools'); ?>"><i class="fa fa-wrench"></i> Tools</a></li> -->
    
          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Vision Group
            <small>Keep Records Right </small>
          </h3>
          <ol class="breadcrumb">
            <li><i class="fa fa-dashboard"></i> Advanced </li>
            <li class="active">Technology</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">

                         <?php echo $content; ?>


        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          Version 2.0
        </div>
        <!-- Default to the left -->
        <strong> All rights reserved. </strong>
      </footer>


    </div><!-- ./wrapper -->

  
<!--[if lt IE 9]>
<script type="text/javascript" src="<?php echo base_url(); ?>asset/js/html5shiv.js"></script>
<![endif]-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/holder.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.file-input.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/parsley/parsley.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/parsley/i18n/id.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/datepicker/locales/bootstrap-datepicker.id.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/dashboard/js/app.js"></script>

<script type="text/javascript">
    var base_url = "<?php echo base_url(); ?>";    
</script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/app.js"></script>



<?php echo $js; ?>

  </body>
</html>

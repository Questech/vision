<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-23 02:51:27 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-23 07:57:23 --> 404 Page Not Found --> robots.txt
ERROR - 2016-03-23 07:57:37 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-03 03:12:03 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-03 09:53:10 --> 404 Page Not Found --> robots.txt
ERROR - 2016-03-03 09:53:11 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-11 03:28:15 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-11 03:28:43 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:29:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-11 03:29:27 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:29:30 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 03:29:32 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 03:35:12 --> 404 Page Not Found --> loans/jquery-1.11.2.js
ERROR - 2016-03-11 03:36:27 --> 404 Page Not Found --> loans/jquery-1.11.2.js
ERROR - 2016-03-11 03:36:53 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:36:55 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 03:36:57 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 03:40:59 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:41:12 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 03:41:13 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 03:43:31 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:43:32 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 03:43:34 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 03:43:56 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:43:58 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 03:44:00 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 03:44:08 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:44:09 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 03:44:11 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 03:44:23 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:44:25 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 03:44:26 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 03:45:07 --> 404 Page Not Found --> loans/jquery-1.11.2.js
ERROR - 2016-03-11 03:48:14 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:48:15 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 03:48:17 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 03:53:06 --> 404 Page Not Found --> index2.html
ERROR - 2016-03-11 03:55:41 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 03:56:02 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 03:56:02 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 03:56:10 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-11 03:56:22 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 04:04:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/bakrizho/public_html/application/modules/dashboard/controllers/dashboard.php:2) /home/bakrizho/public_html/system/libraries/Session.php 689
ERROR - 2016-03-11 04:04:31 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 04:07:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/bakrizho/public_html/application/modules/dashboard/controllers/dashboard.php:2) /home/bakrizho/public_html/system/libraries/Session.php 689
ERROR - 2016-03-11 04:07:32 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 04:08:17 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 04:08:20 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 04:08:21 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 04:08:31 --> 404 Page Not Found --> loans/jquery-1.11.2.js
ERROR - 2016-03-11 04:11:31 --> 404 Page Not Found --> loans/jquery-1.11.2.js
ERROR - 2016-03-11 04:14:05 --> 404 Page Not Found --> loans/jquery-1.11.2.js
ERROR - 2016-03-11 04:14:18 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 04:14:19 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 04:14:21 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 04:14:34 --> Severity: Notice  --> Undefined index: month /home/bakrizho/public_html/application/modules/montly_contribution/views/form.php 31
ERROR - 2016-03-11 04:14:34 --> Severity: Notice  --> Undefined index: amount /home/bakrizho/public_html/application/modules/montly_contribution/views/form.php 50
ERROR - 2016-03-11 04:14:34 --> Severity: Notice  --> Undefined index: user /home/bakrizho/public_html/application/modules/montly_contribution/views/form.php 64
ERROR - 2016-03-11 04:14:48 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 04:14:50 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 04:14:51 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 06:58:40 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-11 06:59:22 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:00:02 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:00:05 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 07:00:06 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 07:02:36 --> Severity: Notice  --> Undefined index: month /home/bakrizho/public_html/application/modules/montly_contribution/views/form.php 31
ERROR - 2016-03-11 07:02:36 --> Severity: Notice  --> Undefined index: amount /home/bakrizho/public_html/application/modules/montly_contribution/views/form.php 50
ERROR - 2016-03-11 07:02:36 --> Severity: Notice  --> Undefined index: user /home/bakrizho/public_html/application/modules/montly_contribution/views/form.php 64
ERROR - 2016-03-11 07:03:31 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:03:34 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 07:03:35 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 07:07:40 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:07:42 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 07:07:43 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 07:09:14 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-11 07:09:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-11 07:09:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-11 07:09:43 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:09:44 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:09:55 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:09:56 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 07:09:56 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 07:11:20 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-11 07:11:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-11 07:11:54 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:12:19 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:12:20 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 07:12:20 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 07:16:06 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-03-11 07:16:07 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-03-11 07:16:07 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-03-11 12:04:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-11 12:12:03 --> 404 Page Not Found --> .well-known/autoconfig/mail/config-v1.1.xml
ERROR - 2016-03-11 12:13:46 --> 404 Page Not Found --> .well-known/autoconfig/mail/config-v1.1.xml
ERROR - 2016-03-11 12:17:29 --> 404 Page Not Found --> .well-known/autoconfig/mail/config-v1.1.xml
ERROR - 2016-03-11 12:37:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-11 12:37:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-11 15:47:19 --> 404 Page Not Found --> .well-known/autoconfig/mail/config-v1.1.xml

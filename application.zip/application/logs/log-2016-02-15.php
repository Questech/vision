<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-15 18:34:27 --> 404 Page Not Found --> robots.txt

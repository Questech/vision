<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-22 08:08:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-22 08:09:26 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-22 10:31:10 --> 404 Page Not Found --> favicon.ico

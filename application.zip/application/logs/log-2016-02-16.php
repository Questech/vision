<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-16 07:55:00 --> 404 Page Not Found --> robots.txt

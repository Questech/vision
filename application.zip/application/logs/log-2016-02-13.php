<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-13 03:46:22 --> Unable to select database: bakrizho_vision
ERROR - 2016-02-13 03:46:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-13 03:50:42 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:50:42 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:50:42 --> Unable to connect to the database
ERROR - 2016-02-13 03:52:04 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:52:04 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:52:04 --> Unable to connect to the database
ERROR - 2016-02-13 03:53:48 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:53:48 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:53:48 --> Unable to connect to the database
ERROR - 2016-02-13 03:54:30 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:54:30 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:54:30 --> Unable to connect to the database
ERROR - 2016-02-13 03:54:33 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:54:33 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:54:33 --> Unable to connect to the database
ERROR - 2016-02-13 03:56:40 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:56:40 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:56:40 --> Unable to connect to the database
ERROR - 2016-02-13 03:58:16 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:58:16 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 03:58:16 --> Unable to connect to the database
ERROR - 2016-02-13 04:09:02 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:09:02 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:09:02 --> Unable to connect to the database
ERROR - 2016-02-13 04:09:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-13 04:09:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-13 04:11:50 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:11:50 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:11:50 --> Unable to connect to the database
ERROR - 2016-02-13 04:12:37 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:12:37 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:12:37 --> Unable to connect to the database
ERROR - 2016-02-13 04:13:56 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:13:56 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:13:56 --> Unable to connect to the database
ERROR - 2016-02-13 04:17:16 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:17:16 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/bakrizho/public_html/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-13 04:17:16 --> Unable to connect to the database
ERROR - 2016-02-13 04:18:06 --> Unable to select database: bakrizho_vision
ERROR - 2016-02-13 04:19:46 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:20:27 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:20:28 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:20:30 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:20:38 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:20:39 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:20:39 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:21:20 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:22:01 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:22:12 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:22:12 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:22:13 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:22:22 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:22:22 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:22:23 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:22:27 --> 404 Page Not Found --> users/jquery-1.11.2.js
ERROR - 2016-02-13 04:23:04 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:23:04 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:23:04 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:23:09 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:23:10 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:23:10 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:23:14 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:23:14 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:23:14 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:23:54 --> 404 Page Not Found --> loans/jquery-1.11.2.js
ERROR - 2016-02-13 04:24:43 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:24:44 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:24:44 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:29:23 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:29:24 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:29:25 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:37:19 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:37:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-13 04:37:42 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:39:03 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:39:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-13 04:39:12 --> 404 Page Not Found --> add_loan/jquery-1.11.2.js
ERROR - 2016-02-13 04:39:13 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:39:54 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:39:54 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:39:55 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:39:57 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:40:10 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:40:14 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:40:23 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:40:40 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:40:43 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:40:48 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:40:50 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:40:51 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:40:58 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:40:58 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:40:58 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:42:14 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:42:15 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:42:15 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:42:25 --> 404 Page Not Found --> users/jquery-1.11.2.js
ERROR - 2016-02-13 04:42:34 --> Severity: Notice  --> Undefined index: fname /home/bakrizho/public_html/application/modules/users/views/form.php 31
ERROR - 2016-02-13 04:42:34 --> Severity: Notice  --> Undefined index: mname /home/bakrizho/public_html/application/modules/users/views/form.php 50
ERROR - 2016-02-13 04:42:34 --> Severity: Notice  --> Undefined index: lname /home/bakrizho/public_html/application/modules/users/views/form.php 69
ERROR - 2016-02-13 04:42:34 --> Severity: Notice  --> Undefined index: id_no /home/bakrizho/public_html/application/modules/users/views/form.php 88
ERROR - 2016-02-13 04:42:34 --> Severity: Notice  --> Undefined index: phn_no /home/bakrizho/public_html/application/modules/users/views/form.php 107
ERROR - 2016-02-13 04:42:39 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:42:39 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:42:39 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:42:42 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 04:42:42 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 04:42:42 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 04:42:56 --> 404 Page Not Found --> loan_type/jquery-1.11.2.js
ERROR - 2016-02-13 04:51:49 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 04:51:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-13 06:11:21 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-13 06:11:34 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 06:11:36 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 06:11:54 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 06:11:56 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 06:11:56 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 06:13:28 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 06:13:28 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 06:13:28 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 06:13:32 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-13 06:13:33 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-13 06:13:33 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-13 06:13:40 --> 404 Page Not Found --> loans/jquery-1.11.2.js
ERROR - 2016-02-13 06:13:43 --> 404 Page Not Found --> loans/jquery-1.11.2.js
ERROR - 2016-02-13 21:06:54 --> 404 Page Not Found --> robots.txt

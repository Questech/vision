<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-22 12:58:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-22 12:58:22 --> 404 Page Not Found --> sitemap.xml
ERROR - 2016-02-22 12:58:22 --> 404 Page Not Found --> robots.txt

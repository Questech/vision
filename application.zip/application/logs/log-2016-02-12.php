<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-12 22:27:09 --> Unable to select database: bakrizho_vision

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-01 06:27:51 --> 404 Page Not Found --> robots.txt

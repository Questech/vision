<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-24 04:45:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-24 04:45:37 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-29 00:40:22 --> 404 Page Not Found --> robots.txt

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-28 02:00:48 --> 404 Page Not Found --> robots.txt
ERROR - 2016-02-28 16:18:35 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-28 16:18:37 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-28 17:28:07 --> 404 Page Not Found --> wp-login.php
ERROR - 2016-02-28 17:28:07 --> 404 Page Not Found --> administrator
ERROR - 2016-02-28 17:28:08 --> 404 Page Not Found --> admin.php

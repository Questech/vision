<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-17 13:20:07 --> 404 Page Not Found --> robots.txt
ERROR - 2016-02-17 13:20:09 --> 404 Page Not Found --> xmlrpc.php
ERROR - 2016-02-17 13:20:09 --> 404 Page Not Found --> blog/robots.txt
ERROR - 2016-02-17 13:20:10 --> 404 Page Not Found --> blog
ERROR - 2016-02-17 13:20:10 --> 404 Page Not Found --> wordpress
ERROR - 2016-02-17 13:20:10 --> 404 Page Not Found --> wp
ERROR - 2016-02-17 17:32:19 --> 404 Page Not Found --> admin
ERROR - 2016-02-17 17:32:20 --> 404 Page Not Found --> downloader

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-18 03:49:29 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-18 03:49:34 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-18 06:37:01 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-18 06:37:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-18 06:37:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-18 17:07:35 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-18 18:01:34 --> 404 Page Not Found --> robots.txt
ERROR - 2016-03-18 18:01:39 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css

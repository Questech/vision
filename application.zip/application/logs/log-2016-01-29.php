<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-29 02:37:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 02:37:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:37:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:37:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 02:37:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:37:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:37:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 02:37:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:37:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 02:37:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:37:50 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 02:37:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:37:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 02:37:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 02:48:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 02:49:10 --> 404 Page Not Found --> membership
ERROR - 2016-01-29 03:59:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 03:59:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 03:59:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 03:59:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 03:59:15 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 03:59:15 --> 404 Page Not Found --> assets/admin/css/bootstrap.min.css
ERROR - 2016-01-29 03:59:15 --> 404 Page Not Found --> assets/admin/css/login.css
ERROR - 2016-01-29 03:59:15 --> 404 Page Not Found --> assets/admin/img/visionlogo1.png
ERROR - 2016-01-29 03:59:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 03:59:16 --> 404 Page Not Found --> assets/admin/css/bootstrap.min.css
ERROR - 2016-01-29 03:59:16 --> 404 Page Not Found --> assets/admin/css/login.css
ERROR - 2016-01-29 03:59:16 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 03:59:16 --> 404 Page Not Found --> assets/admin/img/visionlogo1.png
ERROR - 2016-01-29 04:05:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:05:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 04:05:58 --> 404 Page Not Found --> assets/admin/css/bootstrap.min.css
ERROR - 2016-01-29 04:05:58 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:05:58 --> 404 Page Not Found --> assets/admin/css/login.css
ERROR - 2016-01-29 04:05:58 --> 404 Page Not Found --> assets/admin/img/visionlogo1.png
ERROR - 2016-01-29 04:05:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 04:05:58 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:05:58 --> 404 Page Not Found --> assets/admin/css/login.css
ERROR - 2016-01-29 04:05:58 --> 404 Page Not Found --> assets/admin/css/bootstrap.min.css
ERROR - 2016-01-29 04:06:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:06:39 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:06:39 --> 404 Page Not Found --> assets/admin/css/bootstrap.min.css
ERROR - 2016-01-29 04:06:39 --> 404 Page Not Found --> assets/admin/css/login.css
ERROR - 2016-01-29 04:06:39 --> 404 Page Not Found --> assets/admin/img/visionlogo1.png
ERROR - 2016-01-29 04:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:10:03 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:10:03 --> 404 Page Not Found --> assets/admin/css/login.css
ERROR - 2016-01-29 04:10:03 --> 404 Page Not Found --> assets/admin/img/visionlogo1.png
ERROR - 2016-01-29 04:10:03 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:10:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:10:46 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:10:46 --> 404 Page Not Found --> assets/admin/img/visionlogo1.png
ERROR - 2016-01-29 04:10:46 --> 404 Page Not Found --> assets/img/bg.jpg
ERROR - 2016-01-29 04:10:52 --> 404 Page Not Found --> assets/img/bg.jpg
ERROR - 2016-01-29 04:12:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:12:55 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:12:55 --> 404 Page Not Found --> assets/admin/img/visionlogo1.png
ERROR - 2016-01-29 04:12:55 --> 404 Page Not Found --> assets/img/bg.jpg
ERROR - 2016-01-29 04:16:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:16:35 --> 404 Page Not Found --> assets/admin/img/visionlogo1.png
ERROR - 2016-01-29 04:16:35 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:18:13 --> 404 Page Not Found --> assets/admin/img/visionlogo1.png
ERROR - 2016-01-29 04:19:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:19:18 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:19:18 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:19:26 --> 404 Page Not Found --> admin/login/validate_credentials
ERROR - 2016-01-29 04:21:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:21:58 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:22:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:22:09 --> 404 Page Not Found --> users/validate_credentials
ERROR - 2016-01-29 04:22:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:22:27 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:25:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:27:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:27:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:27:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:30:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:30:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:31:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:31:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 04:31:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 04:31:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:32:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:32:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:32:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:32:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:35:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:35:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:36:00 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:40:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:40:47 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:40:49 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:40:49 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:40:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:40:55 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:41:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:42:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:42:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:48:33 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:48:35 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 04:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:50:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 04:50:27 --> Severity: Notice  --> Undefined property: Users::$Users_model /var/www/html/vision/application/modules/users/controllers/users.php 60
ERROR - 2016-01-29 04:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:00:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:04:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:23:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:23:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:34:17 --> Severity: Notice  --> Undefined property: Users::$Users_model /var/www/html/vision/application/modules/users/controllers/users.php 60
ERROR - 2016-01-29 05:34:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:34:37 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 05:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:34:57 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 05:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:35:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:35:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:36:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:36:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:36:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:36:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:36:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:36:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:36:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:36:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:36:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:36:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:36:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:43:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:43:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:43:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:43:50 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:43:52 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 05:43:52 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 05:44:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:44:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:44:08 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:44:08 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:44:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:44:10 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 05:44:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:44:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:44:30 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:47:36 --> 404 Page Not Found --> user
ERROR - 2016-01-29 05:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:49:03 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 05:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:49:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:49:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:49:14 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:49:14 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:52:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:52:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:53:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:53:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:53:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:53:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:53:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:53:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:53:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:54:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:54:01 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 05:54:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:54:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:54:10 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 05:56:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:56:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:56:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:56:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:57:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:57:14 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:14 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:57:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:57:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:57:33 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 05:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:57:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 05:57:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 05:57:42 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 06:16:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:16:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:16:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:16:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:17:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:17:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:17:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:17:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:17:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:17:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:19:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:19:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:19:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:19:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:19:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:20:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:20:05 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:20:05 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:21:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:21:54 --> 404 Page Not Found --> users/logout
ERROR - 2016-01-29 06:22:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:22:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:22:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:22:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:22:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:28:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:28:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:28:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:36:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:36:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:36:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:36:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:36:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:36:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:47:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:47:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:47:50 --> 404 Page Not Found --> usersadmin
ERROR - 2016-01-29 06:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 06:47:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 06:47:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:04:50 --> 404 Page Not Found --> membership
ERROR - 2016-01-29 07:06:14 --> 404 Page Not Found --> membership
ERROR - 2016-01-29 07:06:21 --> 404 Page Not Found --> membership/index
ERROR - 2016-01-29 07:06:45 --> 404 Page Not Found --> membership/index
ERROR - 2016-01-29 07:06:47 --> 404 Page Not Found --> membership/index
ERROR - 2016-01-29 07:06:47 --> 404 Page Not Found --> membership/index
ERROR - 2016-01-29 07:06:58 --> 404 Page Not Found --> membership/index
ERROR - 2016-01-29 07:28:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:28:02 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:28:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:28:10 --> 404 Page Not Found --> users/validate_credentials
ERROR - 2016-01-29 07:30:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:30:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:32:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:32:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:32:19 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:33:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:33:41 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:33:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:33:43 --> Severity: Notice  --> Undefined property: membership::$membership_model /var/www/html/vision/application/modules/membership/controllers/membership.php 60
ERROR - 2016-01-29 07:34:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:34:30 --> Severity: Notice  --> Undefined property: membership::$membership_model /var/www/html/vision/application/modules/membership/controllers/membership.php 60
ERROR - 2016-01-29 07:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:36:01 --> Severity: Notice  --> Undefined property: membership::$membership_model /var/www/html/vision/application/modules/membership/controllers/membership.php 60
ERROR - 2016-01-29 07:36:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:36:09 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:36:09 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:36:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:36:13 --> Severity: Notice  --> Undefined property: membership::$membership_model /var/www/html/vision/application/modules/membership/controllers/membership.php 60
ERROR - 2016-01-29 07:37:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:37:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:37:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:38:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:38:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:38:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:38:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:38:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:39:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:39:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:39:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:39:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:39:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:39:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:39:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:39:36 --> Severity: Notice  --> Undefined variable: userss /var/www/html/vision/application/modules/users/views/view.php 43
ERROR - 2016-01-29 07:39:36 --> Severity: Notice  --> Undefined variable: total /var/www/html/vision/application/modules/users/views/view.php 123
ERROR - 2016-01-29 07:39:36 --> Severity: Notice  --> Undefined variable: pagination /var/www/html/vision/application/modules/users/views/view.php 127
ERROR - 2016-01-29 07:40:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:40:01 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:40:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:40:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:40:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:40:12 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:40:12 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:40:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:40:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:40:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:40:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:40:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:40:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:40:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:40:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:40:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:40:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:41:09 --> 404 Page Not Found --> users/membership
ERROR - 2016-01-29 07:41:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:41:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:41:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:41:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:41:24 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:41:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:41:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:41:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:41:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:41:32 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:41:32 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:42:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:09 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:42:09 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:42:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:41 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:42:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:42:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:42:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:42:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:42:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:50 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:42:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:54 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:42:54 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:42:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:42:58 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:42:58 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:43:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:04 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:43:04 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:43:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:15 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:21 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:29 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:43:44 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:44 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-29 07:43:51 --> 404 Page Not Found --> usersadmin
ERROR - 2016-01-29 07:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:44:35 --> 404 Page Not Found --> assets/img/avator5.jpg
ERROR - 2016-01-29 07:44:35 --> 404 Page Not Found --> assets/img/avator5.jpg
ERROR - 2016-01-29 07:44:42 --> 404 Page Not Found --> assets/img/avator5.jpg
ERROR - 2016-01-29 07:45:27 --> 404 Page Not Found --> assets/img/avator5.jpg
ERROR - 2016-01-29 07:45:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:45:30 --> 404 Page Not Found --> assets/img/avator5.png
ERROR - 2016-01-29 07:45:30 --> 404 Page Not Found --> assets/img/avator5.png
ERROR - 2016-01-29 07:45:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:45:31 --> 404 Page Not Found --> assets/img/avator5.png
ERROR - 2016-01-29 07:45:31 --> 404 Page Not Found --> assets/img/avator5.png
ERROR - 2016-01-29 07:45:33 --> 404 Page Not Found --> assets/img/avator5.png
ERROR - 2016-01-29 07:45:49 --> 404 Page Not Found --> assets/img/avator5.png
ERROR - 2016-01-29 07:45:50 --> 404 Page Not Found --> assets/img/avator5.png
ERROR - 2016-01-29 07:45:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:51:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:53:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:54:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:54:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:54:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:54:25 --> 404 Page Not Found --> loan_types
ERROR - 2016-01-29 07:54:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:56:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:56:09 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:56:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:56:12 --> Severity: Notice  --> Undefined variable: userss /var/www/html/vision/application/modules/users/views/view.php 43
ERROR - 2016-01-29 07:56:12 --> Severity: Notice  --> Undefined variable: total /var/www/html/vision/application/modules/users/views/view.php 123
ERROR - 2016-01-29 07:56:12 --> Severity: Notice  --> Undefined variable: pagination /var/www/html/vision/application/modules/users/views/view.php 127
ERROR - 2016-01-29 07:56:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:56:47 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:56:47 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:56:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:56:50 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:56:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:56:52 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:56:52 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:56:53 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:57:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:57:05 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-01-29 07:57:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:57:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:57:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:57:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 07:57:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:07:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:09:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:09:37 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:10:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:10:26 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:10:27 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:10:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:10:29 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:10:29 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:10:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:10:40 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:10:40 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:10:41 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:10:41 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:11:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:11:03 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:11:04 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:11:04 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:11:04 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:11:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:11:49 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:11:49 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:11:49 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:11:49 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:11:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:11:55 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:11:55 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:11:55 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:11:55 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:12:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:12:39 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:12:40 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:05 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:05 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:07 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:07 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:07 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:13:07 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:08 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:09 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:10 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:10 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:10 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:13:10 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:13:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:11 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:11 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:13 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:13 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:14 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:14 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:16 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:16 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:23 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:23 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:24 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:24 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:25 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:25 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:26 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:26 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:26 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:13:27 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:13:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:31 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:32 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:32 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:13:32 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:13:37 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:37 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:13:37 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:13:38 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:16:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:16:43 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:16:43 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:17:03 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:03 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:03 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:17:03 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:17:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:17:06 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:06 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:06 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:17:06 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:17:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:17:08 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:08 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:08 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:17:08 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:17:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:17:10 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:10 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:10 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:17:10 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:17:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:17:11 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:11 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:12 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:17:12 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:17:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:17:13 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:13 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:17:14 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:17:14 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:20:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:20:17 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:20:17 --> 404 Page Not Found --> %20assets/img/visionlogo1.png
ERROR - 2016-01-29 08:20:17 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:20:17 --> 404 Page Not Found --> %20assets/img/visionlogo1.png
ERROR - 2016-01-29 08:20:20 --> 404 Page Not Found --> %20assets/img/visionlogo1.png
ERROR - 2016-01-29 08:20:50 --> 404 Page Not Found --> %20assets/img/Visionlogo1.png
ERROR - 2016-01-29 08:21:22 --> 404 Page Not Found --> %20assets/img/Visionlogo1.png
ERROR - 2016-01-29 08:21:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:21:28 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:21:28 --> 404 Page Not Found --> %20assets/img/bg.jpg
ERROR - 2016-01-29 08:21:28 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:21:28 --> 404 Page Not Found --> %20assets/img/bg.jpg
ERROR - 2016-01-29 08:21:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:21:29 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:21:29 --> 404 Page Not Found --> %20assets/img/bg.jpg
ERROR - 2016-01-29 08:21:30 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:21:30 --> 404 Page Not Found --> %20assets/img/bg.jpg
ERROR - 2016-01-29 08:21:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:21:31 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:21:31 --> 404 Page Not Found --> %20assets/img/bg.jpg
ERROR - 2016-01-29 08:21:31 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:21:31 --> 404 Page Not Found --> %20assets/img/bg.jpg
ERROR - 2016-01-29 08:22:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:22:15 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:22:15 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:22:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:22:32 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:22:32 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:22:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:22:47 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:22:48 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:23:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:23:15 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:23:15 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:25:44 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:25:44 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:25:44 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:25:44 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:25:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:25:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:25:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:25:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:26:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:26:02 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:26:02 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:26:02 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:26:02 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:26:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:26:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:26:05 --> Severity: Notice  --> Undefined index: month /var/www/html/vision/application/modules/montly_contribution/views/form.php 31
ERROR - 2016-01-29 08:26:05 --> Severity: Notice  --> Undefined index: amount /var/www/html/vision/application/modules/montly_contribution/views/form.php 50
ERROR - 2016-01-29 08:26:05 --> Severity: Notice  --> Undefined index: user /var/www/html/vision/application/modules/montly_contribution/views/form.php 64
ERROR - 2016-01-29 08:27:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:27:48 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:27:48 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:27:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:27:56 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:27:56 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:27:56 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:27:56 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:27:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:27:58 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:27:58 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:52:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:52:46 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:52:46 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-01-29 08:52:46 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-01-29 08:52:46 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-01-29 08:52:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:52:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:52:48 --> 404 Page Not Found --> montly_contribution/jquery-1.11.2.js
ERROR - 2016-01-29 08:52:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:52:49 --> 404 Page Not Found --> montly_contribution/jquery-1.11.2.js
ERROR - 2016-01-29 08:53:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-29 08:53:14 --> 404 Page Not Found --> montly_contribution/membership

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-01 01:17:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:17:26 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-01 01:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:17:37 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:17:38 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:17:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:17:44 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:17:45 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:17:45 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:17:45 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:17:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:17:51 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:17:51 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:17:51 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:17:51 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:18:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:18:50 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:18:51 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:18:51 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:18:51 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:19:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:04 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:04 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:04 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:19:04 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:19:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:06 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:06 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:06 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:19:06 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:11 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:11 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:11 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:19:11 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:19:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:22 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:22 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:22 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:19:22 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:19:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:25 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:25 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:26 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:19:26 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:19:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:29 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:30 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:30 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:19:30 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:19:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:32 --> 404 Page Not Found --> users/jquery-1.11.2.js
ERROR - 2016-02-01 01:19:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:32 --> 404 Page Not Found --> users/jquery-1.11.2.js
ERROR - 2016-02-01 01:19:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:19:56 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:19:56 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:20:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:20:11 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:20:11 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:20:11 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:20:11 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:20:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:20:15 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:20:15 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:20:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:20:50 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:20:50 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:20:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:20:52 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:20:52 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-01 01:20:53 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-01 01:20:53 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-01 01:20:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-02-01 01:20:55 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css

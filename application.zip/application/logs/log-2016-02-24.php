<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-24 10:28:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-24 18:59:34 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css

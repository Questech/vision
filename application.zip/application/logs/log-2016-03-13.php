<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-13 19:08:07 --> 404 Page Not Found --> robots.txt

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-25 09:55:54 --> 404 Page Not Found --> robots.txt
ERROR - 2016-02-25 23:16:44 --> 404 Page Not Found --> robots.txt

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-26 00:05:11 --> 404 Page Not Found --> mobile
ERROR - 2016-02-26 00:12:30 --> 404 Page Not Found --> m

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-19 02:59:36 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css

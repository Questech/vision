<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-16 16:40:57 --> 404 Page Not Found --> robots.txt
ERROR - 2016-03-16 16:41:01 --> 404 Page Not Found --> robots.txt
ERROR - 2016-03-16 16:41:05 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-03-16 22:06:58 --> 404 Page Not Found --> robots.txt

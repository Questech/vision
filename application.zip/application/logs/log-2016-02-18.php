<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-18 10:21:17 --> 404 Page Not Found --> assets/font-awesome-4.4.0/css/font-awesome.css
ERROR - 2016-02-18 10:21:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-18 10:21:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-02-18 10:22:03 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-18 10:22:07 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-18 10:22:35 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-18 10:22:43 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-18 10:22:44 --> 404 Page Not Found --> assets/images/sort_asc.png
ERROR - 2016-02-18 10:23:12 --> 404 Page Not Found --> jquery-1.11.2.js
ERROR - 2016-02-18 10:23:45 --> 404 Page Not Found --> assets/images/sort_both.png
ERROR - 2016-02-18 10:23:46 --> 404 Page Not Found --> assets/images/sort_asc.png

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-14 07:48:53 --> 404 Page Not Found --> robots.txt

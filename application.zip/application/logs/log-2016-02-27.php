<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-27 11:16:22 --> 404 Page Not Found --> robots.txt
ERROR - 2016-02-27 12:10:17 --> 404 Page Not Found --> wp-content/plugins/wp-easy-gallery-pro/admin/php.php
ERROR - 2016-02-27 14:36:24 --> 404 Page Not Found --> m

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-03-17 08:03:14 --> 404 Page Not Found --> administrator/index.php
ERROR - 2016-03-17 14:25:21 --> 404 Page Not Found --> robots.txt
ERROR - 2016-03-17 16:51:03 --> 404 Page Not Found --> robots.txt
ERROR - 2016-03-17 17:16:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2016-03-17 17:16:24 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-25 02:55:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:55:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:56:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:56:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:56:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:57:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:57:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:58:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:58:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:58:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:58:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:59:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:59:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:59:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:59:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 02:59:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:04:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:04:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:04:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:04:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:05:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:05:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:05:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:05:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:05:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:05:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:05:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:05:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:05:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:05:18 --> Query error: Table 'vision.test' doesn't exist
ERROR - 2016-01-25 03:05:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:05:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:05:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:06:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:06:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:06:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:06:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:06:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:06:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:06:09 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/montly_contribution/views/form.php 63
ERROR - 2016-01-25 03:06:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 03:06:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:06:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:09:17 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/montly_contribution/views/form.php 63
ERROR - 2016-01-25 03:09:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 03:09:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:09:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:09:37 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/loans/views/form.php 25
ERROR - 2016-01-25 03:09:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 03:09:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:09:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:09:43 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/fines/views/form.php 44
ERROR - 2016-01-25 03:09:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 03:09:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:09:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:09:48 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/loans/views/form.php 25
ERROR - 2016-01-25 03:09:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 03:09:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:09:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:09:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:12:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:12:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:12:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:12:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:12:10 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/montly_contribution/views/form.php 63
ERROR - 2016-01-25 03:12:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 03:12:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:12:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:12:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:12:14 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/montly_contribution/views/form.php 63
ERROR - 2016-01-25 03:12:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 03:12:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:12:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:14:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:14:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:14:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:14:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:14:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:14:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:14:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:14:57 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/montly_contribution/views/form.php 63
ERROR - 2016-01-25 03:14:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 03:14:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:14:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:15:33 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/montly_contribution/views/form.php 63
ERROR - 2016-01-25 03:15:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 03:15:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:15:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:16:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:16:02 --> Severity: Notice  --> Undefined index: users /var/www/html/vision/application/modules/montly_contribution/views/form.php 64
ERROR - 2016-01-25 03:16:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:16:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:16:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:16:34 --> Severity: Notice  --> Undefined index: users /var/www/html/vision/application/modules/montly_contribution/views/form.php 64
ERROR - 2016-01-25 03:16:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:16:35 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:16:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:16:38 --> Severity: Notice  --> Undefined index: users /var/www/html/vision/application/modules/montly_contribution/views/form.php 64
ERROR - 2016-01-25 03:16:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:16:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:17:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:17:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:19:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:19:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:19:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:19:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:19:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:19:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:19:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:19:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:19:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:19:20 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:19:20 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:21:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:21:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:21:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:48:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:48:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:48:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:48:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:48:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:48:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:48:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:48:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:49:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:49:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:49:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:49:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:49:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:49:06 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:49:06 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:50:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:50:50 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:50:50 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:50:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:50:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:50:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:50:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:50:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:53:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:53:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:53:30 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:30 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:53:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:53:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:53:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:53:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:54:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:54:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:54:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:55:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:55:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:55:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:55:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:55:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:55:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:55:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:56:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:56:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:56:20 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:20 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:56:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:56:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:56:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:56:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:56:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:56:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:57:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:57:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:57:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:57:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:58:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:58:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:58:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 03:58:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 03:58:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:08 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:01:08 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:01:08 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:01:08 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:08 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:23 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:01:23 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:01:23 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:01:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:24 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:01:24 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:01:24 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:01:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:24 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:01:24 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:01:24 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:01:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:25 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:01:25 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:01:25 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:01:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:26 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:01:26 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:01:26 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:01:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:26 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:01:26 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:01:26 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:01:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:27 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:01:27 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:01:27 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:01:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:27 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:01:27 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:01:27 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:01:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:32 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:32 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:50 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:01:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:01:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:02:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:04:23 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:04:23 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:04:23 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:04:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:04:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:04:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:04:25 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:04:25 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:04:25 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:04:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:04:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:04:27 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 77
ERROR - 2016-01-25 04:04:27 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 85
ERROR - 2016-01-25 04:04:27 --> Severity: Notice  --> Undefined index:  /var/www/html/vision/application/modules/loan_type/views/view.php 93
ERROR - 2016-01-25 04:04:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:04:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:05:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:05:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:05:29 --> Query error: Unknown column ' =  '1'' in 'where clause'
ERROR - 2016-01-25 04:05:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:05:44 --> Query error: Unknown column ' =  '1'' in 'where clause'
ERROR - 2016-01-25 04:06:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:06:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:06:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:06:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:06:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:06:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:06:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:06:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:06:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:06:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:06:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:06:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:06:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:06:54 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:06:54 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:08:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:08:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:08:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:08:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:09:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:09:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:09:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:09:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:09:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:09:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:10:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:10:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:10:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:10:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:11:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:11:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:11:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:11:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:11:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:11:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:11:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:11:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:11:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:11:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:12:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:12:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:12:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:12:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:12:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:12:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:12:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:12:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:12:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:12:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:13:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:13:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:13:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:13:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:13:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:13:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:13:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:13:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:14:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:14:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:14:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:14:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:14:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:14:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:15:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:16:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:16:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:16:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:19:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:19:06 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:19:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:19:08 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:19:08 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:19:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:19:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:20:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:20:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:20:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:21:08 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:21:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:21:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:21:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:21:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:21:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:21:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:22:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:22:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:23:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:14 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:23:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:23:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:23:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:30 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:23:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:23:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:23:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:23:44 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:24:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:24:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:24:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:24:44 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:24:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:24:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:24:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:24:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:24:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:24:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:24:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:25:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:25:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:25:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:25:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:25:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:25:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:25:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:25:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:25:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:26:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:26:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:26:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:26:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:26:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:27:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:27:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:27:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:27:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:27:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:27:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:28:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:28:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:28:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:41:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:41:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:41:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:42:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:43:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:43:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:43:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:43:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:43:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:45:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:45:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:45:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:45:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:45:20 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:45:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:45:21 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/add_loan/views/form.php 25
ERROR - 2016-01-25 04:45:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 04:45:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:45:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:46:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:46:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:46:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:46:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:47:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:47:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:47:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:47:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:47:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:47:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:47:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:47:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:47:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:47:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:47:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:47:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:47:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:50:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:50:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:50:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:50:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:50:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:50:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:50:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:50:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:51:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:51:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:51:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:51:50 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:52:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:52:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:53:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:53:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:56:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:56:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:56:12 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/add_loan/views/form.php 25
ERROR - 2016-01-25 04:56:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 04:56:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:56:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:56:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:56:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:56:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:56:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:57:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:57:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:58:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:58:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:58:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:58:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:58:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:58:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:58:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:58:44 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:58:44 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:59:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:59:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:59:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:59:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:59:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 04:59:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 04:59:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:01:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:01:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:01:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:02:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:02:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:06:14 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:06:14 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:06:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:07:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:07:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:08:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:08:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:08:26 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/add_loan/views/form.php 25
ERROR - 2016-01-25 05:08:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:08:26 --> Severity: Notice  --> Undefined variable: ltype /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:08:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:08:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:08:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:09:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:09:04 --> Severity: Notice  --> Undefined variable: ltype /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:09:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:09:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:09:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:09:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:09:24 --> Severity: Notice  --> Undefined variable: ltypes /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:09:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:09:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:09:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:10:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:10:13 --> Severity: Notice  --> Undefined variable: ltype /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:10:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:10:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:10:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:10:39 --> Severity: Notice  --> Undefined variable: ltypess /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:10:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:10:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:10:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:11:26 --> Severity: Notice  --> Undefined variable: ltype /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:11:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:11:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:11:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:12:07 --> Severity: Notice  --> Undefined variable: ltype /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:12:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:12:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:12:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:12:13 --> Severity: Notice  --> Undefined variable: ltypes /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:12:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:12:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:12:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:13:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:13:05 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:13:06 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:14:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:14:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:14:32 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:14:32 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:14:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:14:36 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/add_loan/views/form.php 25
ERROR - 2016-01-25 05:14:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:14:36 --> Severity: Notice  --> Undefined variable: ltype /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:14:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:14:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:15:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:15:06 --> Severity: Notice  --> Undefined variable: loan_type /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:15:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:15:06 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:15:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:15:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:15:27 --> Severity: Notice  --> Undefined variable: loan_types /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:15:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:15:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:15:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:16:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:16:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:16:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:16:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:17:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:18:34 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/add_loan/views/form.php 25
ERROR - 2016-01-25 05:18:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:18:34 --> Severity: Notice  --> Undefined variable: ltype /var/www/html/vision/application/modules/add_loan/views/form.php 59
ERROR - 2016-01-25 05:18:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 05:18:35 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:18:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:19:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:19:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:20:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:20:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:20:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:20:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:20:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:22 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:22 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:25:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:25:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:27:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:27:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:27:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:28:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:29:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:30:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:30:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:30:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:30:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:30:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:30:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:30:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:30:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:30:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:30:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:30:47 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:31:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:31:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:31:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:31:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:31:44 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:31:44 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:31:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:31:50 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:32:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:32:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:32:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:32:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:32:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 05:33:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 05:33:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:07:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:07:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:07:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:08:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:08:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:08:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:10:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:10:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:11:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:11:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:11:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:11:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:11:30 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/loans/views/form.php 25
ERROR - 2016-01-25 06:11:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 06:11:30 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:11:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:12:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:12:34 --> Severity: Notice  --> Undefined variable: users /var/www/html/vision/application/modules/loans/views/form.php 25
ERROR - 2016-01-25 06:12:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 06:12:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:12:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:13:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:13:16 --> Severity: Notice  --> Undefined variable: users /var/www/html/vision/application/modules/loans/views/form.php 25
ERROR - 2016-01-25 06:13:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 06:13:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:13:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:13:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:13:52 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:13:54 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:14:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:14:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:14:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:24:54 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:24:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:24:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:26:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:26:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:26:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:26:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:26:37 --> Severity: Notice  --> Undefined variable: user /var/www/html/vision/application/modules/loans/views/form.php 25
ERROR - 2016-01-25 06:26:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 06:26:37 --> Severity: Notice  --> Undefined variable: ltype /var/www/html/vision/application/modules/loans/views/form.php 40
ERROR - 2016-01-25 06:26:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 06:26:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:26:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:27:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:27:30 --> Severity: Notice  --> Undefined variable: users /var/www/html/vision/application/modules/loans/views/form.php 25
ERROR - 2016-01-25 06:27:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /var/www/html/vision/system/helpers/form_helper.php 332
ERROR - 2016-01-25 06:27:30 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:27:32 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:10 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:38 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:41 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:28:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:28:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:29:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:32:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:32:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:33:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:33:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:33:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:33:22 --> Severity: Notice  --> Undefined property: stdClass::$remaining /var/www/html/vision/application/modules/loans/models/loanss.php 194
ERROR - 2016-01-25 06:33:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:33:22 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:33:22 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:33:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:33:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:33:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:35:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:35:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:35:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:35:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:35:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:35:30 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:35:30 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:35:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:35:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:35:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:35:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:36:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:36:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:36:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:04 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:36:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:14 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:36:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:27 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:36:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:36:50 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:36:50 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:39:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:40:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:40:05 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:40:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:40:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:40:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:40:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:40:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:40:23 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:40:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:40:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:40:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:40:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:40:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:40:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:40:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:40:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:41:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:41:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:41:06 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:41:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:42:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:42:20 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:42:20 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:46:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:46:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:46:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:46:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:46:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:46:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:46:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:46:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:46:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:46:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:08 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:14 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:28 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:47:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:47:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:48:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:48:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:48:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:48:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:48:45 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:49:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:49:13 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:49:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:17 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:49:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:21 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:49:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:49:54 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:49:57 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:49:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:50:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:50:35 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:35 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:50:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:50:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:50:54 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:50:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:50:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:51:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:51:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:51:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:51:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:51:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:51:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:51:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:51:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:51:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:51:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:51:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:52:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:52:07 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:52:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:52:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:52:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:52:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:52:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:52:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:52:36 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:52:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:52:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:53:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:53:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:53:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:53:15 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:53:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:53:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:54:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:54:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:56:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:56:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:56:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 06:56:20 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 06:56:20 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:11:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:11:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:11:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:12:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:12:01 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:12:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:12:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:12:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:12:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:12:33 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:12:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:12:53 --> Severity: Notice  --> Undefined variable: remaining /var/www/html/vision/application/modules/loans/models/loanss.php 200
ERROR - 2016-01-25 07:12:53 --> Severity: Notice  --> Undefined variable: paid /var/www/html/vision/application/modules/loans/models/loanss.php 201
ERROR - 2016-01-25 07:12:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:12:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:12:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:12:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:12:59 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:14:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:14:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:14:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:14:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:14:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:14:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:14:35 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:14:35 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:20:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:20:08 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:20:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:20:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:20:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:20:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:20:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:20:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '  ltype = 'NORMAL LOAN'' at line 1
ERROR - 2016-01-25 07:20:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:20:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:20:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:20:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:20:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:20:55 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:21:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:21:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:21:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:21:32 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:21:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:21:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:21:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:23:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:23:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:23:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:23:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:23:09 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:23:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:23:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:23:11 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:23:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:23:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:23:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:23:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:23:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:23:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:23:29 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:25:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:25:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:25:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:25:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:25:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:25:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:25:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:25:53 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:27:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:27:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:27:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:27:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:27:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:27:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:12 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:16 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:22 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:22 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:30 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:31 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:43 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:46 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:49 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:28:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:28:51 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:02 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:03 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:19 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:22 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:22 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:34 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:35 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:29:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:29:42 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:30:24 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:25 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:30:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:26 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:30:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:30:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:39 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:30:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:48 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:30:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:30:58 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:31:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:31:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:31:00 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:31:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:31:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:31:18 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:31:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:31:37 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:31:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:31:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:31:40 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:31:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 07:31:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 07:31:56 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 08:25:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/vision/system/database/drivers/mysql/mysql_driver.php 92
ERROR - 2016-01-25 08:25:06 --> 404 Page Not Found --> assets/img/user.jpg
ERROR - 2016-01-25 08:25:06 --> 404 Page Not Found --> assets/img/user.jpg

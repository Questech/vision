<div class="row">
	<div class="col-lg-12 col-md-12">		
		<?php 
                
                echo create_breadcrumb();		
                echo $this->session->flashdata('notify');
                
                ?>
	</div>
</div><!-- /.row -->

<section class="panel panel-default">
    <header class="panel-heading">
        <div class="row">
            <div class="col-md-8 col-xs-3">                
                <?php
                                  echo anchor(
                                           site_url('loans/add'),
                                            '<i class="glyphicon glyphicon-plus"></i>',
                                            'class="btn btn-success btn-sm" data-tooltip="tooltip" data-placement="top" title="Add Data"'
                                          );
                 ?>
                
            </div>
           
        </div>
    </header>
    
    
    <div class="panel-body">
         <?php if ($loanss) : ?>
          <table id="datatable" class="table table-hover table-condensed">
              
            <thead>
              <tr>
                <th class="header">#</th>
                
                    <th>Member</th>   
                
                    <th>Loan type</th>   
                
             <!--       <th>Amount</th>   -->
                
                    <th>Amount Paid</th>   
                
                    <th>Remaining</th>   
                
                    <th>Date</th>   
                
                <th class="red header" align="right" width="120">Actions</th>
              </tr>
            </thead>
            
            
            <tbody>
             
               <?php foreach ($loanss as $loans) : ?>
              <tr>
              	<td><?php echo $number++;; ?> </td>
               
               <td><?php echo $loans['user']; ?></td>
               
               <td><?php echo $loans['ltype']; ?></td>
            <!--   <td><?php echo $loans['amount']; ?></td> -->
               
               <td><?php echo $loans['amount_paid']; ?></td>
               
               <td><?php echo $loans['remaining']; ?></td>
               
               <td><?php echo $loans['date']; ?></td>
               
                <td>    
                    
                    <?php
                                  echo anchor(
                                          site_url('loans/show/' . $loans['id']),
                                            '<i class="glyphicon glyphicon-eye-open"></i>',
                                            'class="btn btn-sm btn-info" data-tooltip="tooltip" data-placement="top" title="Detail"'
                                          );
                   ?>
                    
                    <?php
                                  echo anchor(
                                          site_url('loans/edit/' . $loans['id']),
                                            '<i class="glyphicon glyphicon-edit"></i>',
                                            'class="btn btn-sm btn-success" data-tooltip="tooltip" data-placement="top" title="Edit"'
                                          );
                   ?>
                   
                   <?php
                                  echo anchor(
                                          site_url('loans/destroy/' . $loans['id']),
                                            '<i class="glyphicon glyphicon-trash"></i>',
                                            'onclick="return confirm(\'Are you sure..???\');" class="btn btn-sm btn-danger" data-tooltip="tooltip" data-placement="top" title="Delete"'
                                          );
                   ?>   
                                 
                </td>
              </tr>     
               <?php endforeach; ?>
            </tbody>
          </table>
          <?php else: ?>
                <?php  echo notify('Data loans belum tersedia','info');?>
          <?php endif; ?>
    </div>
    
    
    <div class="panel-footer">
        <div class="row">
           <div class="col-md-3">
               Loans
               <span class="label label-info">
                    <?php echo $total; ?>
               </span>
           </div>  
           <div class="col-md-9">
                 <?php echo $pagination; ?>
           </div>
        </div>
    </div>
</section>
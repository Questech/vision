<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of loans
 * @created on : Monday, 25-Jan-2016 06:26:10
 * @author DAUD D. SIMBOLON <daud.simbolon@gmail.com>
 * Copyright 2016    
 */
 
 
class loanss extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }


    /**
     *  Get All data loans
     *
     *  @param limit  : Integer
     *  @param offset : Integer
     *
     *  @return array
     *
     */
    public function get_all($limit, $offset) 
    {

        $result = $this->db->get('loans', $limit, $offset);

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    

    /**
     *  Count All loans
     *    
     *  @return Integer
     *
     */
    public function count_all()
    {
        $this->db->from('loans');
        return $this->db->count_all_results();
    }
    

    /**
    * Search All loans
    *
    *  @param limit   : Integer
    *  @param offset  : Integer
    *  @param keyword : mixed
    *
    *  @return array
    *
    */
    public function get_search($limit, $offset) 
    {
        $keyword = $this->session->userdata('keyword');
                
        $this->db->like('user', $keyword);  
                
        $this->db->like('ltype', $keyword);  
                
        $this->db->like('date', $keyword);  
        
        $this->db->limit($limit, $offset);
        $result = $this->db->get('loans');

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    
    
    /**
    * Search All loans
    * @param keyword : mixed
    *
    * @return Integer
    *
    */
    public function count_all_search()
    {
        $keyword = $this->session->userdata('keyword');
        $this->db->from('loans');        
                
        $this->db->like('user', $keyword);  
                
        $this->db->like('ltype', $keyword);  
                
        $this->db->like('date', $keyword);  
        
        return $this->db->count_all_results();
    }


    
    
    
    /**
    *  Get One loans
    *
    *  @param id : Integer
    *
    *  @return array
    *
    */
    public function get_one($id) 
    {
        $this->db->where('id', $id);
        $result = $this->db->get('loans');

        if ($result->num_rows() == 1) 
        {
            return $result->row_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    /**
    *  Default form data loans
    *  @return array
    *
    */
    public function add()
    {
        $data = array(
            
                'user' => '',
            
                'ltype' => '',
            
                'amount' => '',
            
                'amount_paid' => '',
            
                'remaining' => '',
            
                'date' => '',
            
        );

        return $data;
    }

    
    
    
    
    /**
    *  Save data Post
    *
    *  @return void
    *
    */
    public function save() 
    {

        $user = $this->input->post('user');
        $amount_paid = $this->input->post('amount_paid');
        $ltype = $this->input->post('ltype');

        $query = $this->db->query("SELECT * FROM add_loan WHERE user = '$user' &&  ltype = '$ltype'");

            foreach ($query->result() as $row)
            {
                    $remaining = $row->remaing;
                    $paid = $row->paid;
                  
            }

            $new_remaining = $remaining-$amount_paid;
            $new_paid = $paid+$amount_paid;

        $data2 = array( 
            'remaing' =>$new_remaining,
            'paid'=>$new_paid,

            );
        $this->db->where('user',$user );
        $this->db->where('ltype',$ltype );
        $this->db->update('add_loan', $data2);


        $data = array(
        
            'user' => strip_tags($this->input->post('user', TRUE)),
        
            'ltype' => strip_tags($this->input->post('ltype', TRUE)),
        
            'amount' => strip_tags($this->input->post('amount', TRUE)),
        
            'amount_paid' => strip_tags($this->input->post('amount_paid', TRUE)),
        
            'remaining' => $new_remaining,
        
            'date' => strip_tags($this->input->post('date', TRUE)),
        
        );
        
        
        $this->db->insert('loans', $data);
    }
    
    
    

    
    /**
    *  Update modify data
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function update($id)
    {
        $data = array(
        
                'user' => strip_tags($this->input->post('user', TRUE)),
        
                'ltype' => strip_tags($this->input->post('ltype', TRUE)),
        
                'amount' => strip_tags($this->input->post('amount', TRUE)),
        
                'amount_paid' => strip_tags($this->input->post('amount_paid', TRUE)),
        
                'remaining' => strip_tags($this->input->post('remaining', TRUE)),
        
                'date' => strip_tags($this->input->post('date', TRUE)),
        
        );
        
        
        $this->db->where('id', $id);
        $this->db->update('loans', $data);
    }


    
    
    
    /**
    *  Delete data by id
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function destroy($id)
    {       
        $this->db->where('id', $id);
        $this->db->delete('loans');
        
    }







    
    
    // get add_loan
    public function get_add_loan() 
    {
      
        $result = $this->db->get('add_loan')
                           ->result();

        $ret ['']= 'Pilih Add Loan :';
        if($result)
        {
            foreach ($result as $key => $row)
            {
                $ret [$row->user] = $row->user;
            }
        }
        
        return $ret;
    }


    
    
    // get loan_type
    public function get_loan_type() 
    {
      
        $result = $this->db->get('loan_type')
                           ->result();

        $ret ['']= 'Pilih Loan Type :';
        if($result)
        {
            foreach ($result as $key => $row)
            {
                $ret [$row->name] = $row->name;
            }
        }
        
        return $ret;
    }


    



}

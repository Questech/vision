<div class="row">
	<div class="col-lg-12 col-md-12">		
		<?php 
                
                echo create_breadcrumb();		
                echo $this->session->flashdata('notify');
                
                ?>
	</div>
</div><!-- /.row -->

<section class="panel panel-default">
    <header class="panel-heading">
        <div class="row">
            <div class="col-md-8 col-xs-3">                
                <?php
                                  echo anchor(
                                           site_url('fines/add'),
                                            '<i class="glyphicon glyphicon-plus"></i>',
                                            'class="btn btn-success btn-sm" data-tooltip="tooltip" data-placement="top" title="Add Data"'
                                          );
                 ?>
                
            </div>
           
        </div>
    </header>
    
    
    <div class="panel-body">
         <?php if ($finess) : ?>
          <table id="datatable" class="table table-hover table-condensed">
              
            <thead>
              <tr>
                <th class="header">#</th>
                
                    <th>Reason</th>   
                
                    <th>Member</th>   
                
                    <th>Date</th>   
                
                    <th>Amount</th>   
                
                <th class="red header" align="right" width="120">Actions</th>
              </tr>
            </thead>
            
            
            <tbody>
             
               <?php foreach ($finess as $fines) : ?>
              <tr>
              	<td><?php echo $number++;; ?> </td>
               
               <td><?php echo $fines['Reason']; ?></td>
               
               <td><?php echo $fines['user']; ?></td>
               
               <td><?php echo $fines['date']; ?></td>
               
               <td><?php echo $fines['amount']; ?></td>
               
                <td>    
                    
                    <?php
                                  echo anchor(
                                          site_url('fines/show/' . $fines['id']),
                                            '<i class="glyphicon glyphicon-eye-open"></i>',
                                            'class="btn btn-sm btn-info" data-tooltip="tooltip" data-placement="top" title="Detail"'
                                          );
                   ?>
                    
                    <?php
                                  echo anchor(
                                          site_url('fines/edit/' . $fines['id']),
                                            '<i class="glyphicon glyphicon-edit"></i>',
                                            'class="btn btn-sm btn-success" data-tooltip="tooltip" data-placement="top" title="Edit"'
                                          );
                   ?>
                   
                   <?php
                                  echo anchor(
                                          site_url('fines/destroy/' . $fines['id']),
                                            '<i class="glyphicon glyphicon-trash"></i>',
                                            'onclick="return confirm(\'Confirm Delete.???\');" class="btn btn-sm btn-danger" data-tooltip="tooltip" data-placement="top" title="Delete"'
                                          );
                   ?>   
                                 
                </td>
              </tr>     
               <?php endforeach; ?>
            </tbody>
          </table>
          <?php else: ?>
                <?php  echo notify('Data fines not yet available','info');?>
          <?php endif; ?>
    </div>
    
    
    <div class="panel-footer">
        <div class="row">
           <div class="col-md-3">
               Fines
               <span class="label label-info">
                    <?php echo $total; ?>
               </span>
           </div>  
           <div class="col-md-9">
                 <?php echo $pagination; ?>
           </div>
        </div>
    </div>
</section>
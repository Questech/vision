<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of fines
 * @created on : Monday, 25-Jan-2016 02:56:03
 * @author DAUD D. SIMBOLON <daud.simbolon@gmail.com>
 * Copyright 2016    
 */
 
 
class finess extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }


    /**
     *  Get All data fines
     *
     *  @param limit  : Integer
     *  @param offset : Integer
     *
     *  @return array
     *
     */
    public function get_all($limit, $offset) 
    {

        $result = $this->db->get('fines', $limit, $offset);

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    

    /**
     *  Count All fines
     *    
     *  @return Integer
     *
     */
    public function count_all()
    {
        $this->db->from('fines');
        return $this->db->count_all_results();
    }
    

    /**
    * Search All fines
    *
    *  @param limit   : Integer
    *  @param offset  : Integer
    *  @param keyword : mixed
    *
    *  @return array
    *
    */
    public function get_search($limit, $offset) 
    {
        $keyword = $this->session->userdata('keyword');
                
        $this->db->like('Reason', $keyword);  
                
        $this->db->like('user', $keyword);  
                
        $this->db->like('date', $keyword);  
        
        $this->db->limit($limit, $offset);
        $result = $this->db->get('fines');

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    
    
    /**
    * Search All fines
    * @param keyword : mixed
    *
    * @return Integer
    *
    */
    public function count_all_search()
    {
        $keyword = $this->session->userdata('keyword');
        $this->db->from('fines');        
                
        $this->db->like('Reason', $keyword);  
                
        $this->db->like('user', $keyword);  
                
        $this->db->like('date', $keyword);  
        
        return $this->db->count_all_results();
    }


    
    
    
    /**
    *  Get One fines
    *
    *  @param id : Integer
    *
    *  @return array
    *
    */
    public function get_one($id) 
    {
        $this->db->where('id', $id);
        $result = $this->db->get('fines');

        if ($result->num_rows() == 1) 
        {
            return $result->row_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    /**
    *  Default form data fines
    *  @return array
    *
    */
    public function add()
    {
        $data = array(
            
                'Reason' => '',
            
                'user' => '',
            
                'date' => '',
            
                'amount' => '',
            
        );

        return $data;
    }

    
    
    
    
    /**
    *  Save data Post
    *
    *  @return void
    *
    */
    public function save() 
    {
        $data = array(
        
            'Reason' => strip_tags($this->input->post('Reason', TRUE)),
        
            'user' => strip_tags($this->input->post('user', TRUE)),
        
            'date' => strip_tags($this->input->post('date', TRUE)),
        
            'amount' => strip_tags($this->input->post('amount', TRUE)),
        
        );
        
        
        $this->db->insert('fines', $data);
    }
    
    
    

    
    /**
    *  Update modify data
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function update($id)
    {
        $data = array(
        
                'Reason' => strip_tags($this->input->post('Reason', TRUE)),
        
                'user' => strip_tags($this->input->post('user', TRUE)),
        
                'date' => strip_tags($this->input->post('date', TRUE)),
        
                'amount' => strip_tags($this->input->post('amount', TRUE)),
        
        );
        
        
        $this->db->where('id', $id);
        $this->db->update('fines', $data);
    }


    
    
    
    /**
    *  Delete data by id
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function destroy($id)
    {       
        $this->db->where('id', $id);
        $this->db->delete('fines');
        
    }







    
    
    // get users
    public function get_users() 
    {
      
        $result = $this->db->get('users')
                           ->result();

        $ret ['']= 'Select Users :';
        if($result)
        {
            foreach ($result as $key => $row)
            {
                $ret [$row->fname] = $row->fname;
            }
        }
        
        return $ret;
    }


    



}

<div class="row">
	<div class="col-lg-12 col-md-12">		
		<?php 
                
                echo create_breadcrumb();		
                echo $this->session->flashdata('notify');
                
                ?>
	</div>
</div><!-- /.row -->

<section class="panel panel-default">
    <header class="panel-heading">
        <div class="row">
            <div class="col-md-8 col-xs-3">                
                <?php
                                  echo anchor(
                                           site_url('loan_type/add'),
                                            '<i class="glyphicon glyphicon-plus"></i>',
                                            'class="btn btn-success btn-sm" data-tooltip="tooltip" data-placement="top" title="Add Data"'
                                          );
                 ?>
                
            </div>
           
        </div>
    </header>
    
    
    <div class="panel-body">
         <?php if ($loan_types) : ?>
          <table  id="datatable" class="table table-hover table-condensed">
              
            <thead>
              <tr>
                <th class="header">#</th>
                
                    <th>Name</th>   
                
                    <th>Interest</th>   
                
                <th class="red header" align="right" width="120">Actions</th>
              </tr>
            </thead>
            
            
            <tbody>
             
               <?php foreach ($loan_types as $loan_type) : ?>
              <tr>
              	<td><?php echo $number++;; ?> </td>
               
               <td><?php echo $loan_type['name']; ?></td>
               
               <td><?php echo $loan_type['interest']; ?></td>
               
                <td>    
                    
                    <?php
                                  echo anchor(
                                          site_url('loan_type/show/' . $loan_type['id']),
                                            '<i class="glyphicon glyphicon-eye-open"></i>',
                                            'class="btn btn-sm btn-info" data-tooltip="tooltip" data-placement="top" title="Detail"'
                                          );
                   ?>
                    
                    <?php
                                  echo anchor(
                                          site_url('loan_type/edit/' . $loan_type['id']),
                                            '<i class="glyphicon glyphicon-edit"></i>',
                                            'class="btn btn-sm btn-success" data-tooltip="tooltip" data-placement="top" title="Edit"'
                                          );
                   ?>
                   
                   <?php
                                  echo anchor(
                                          site_url('loan_type/destroy/' . $loan_type['id']),
                                            '<i class="glyphicon glyphicon-trash"></i>',
                                            'onclick="return confirm(\'confirm delete..???\');" class="btn btn-sm btn-danger" data-tooltip="tooltip" data-placement="top" title="Delete"'
                                          );
                   ?>   
                                 
                </td>
              </tr>     
               <?php endforeach; ?>
            </tbody>
          </table>
          <?php else: ?>
                <?php  echo notify('Data loan_type not yet available','info');?>
          <?php endif; ?>
    </div>
    
    
    <div class="panel-footer">
        <div class="row">
           <div class="col-md-3">
               Loan Type
               <span class="label label-info">
                    <?php echo $total; ?>
               </span>
           </div>  
           <div class="col-md-9">
                 <?php echo $pagination; ?>
           </div>
        </div>
    </div>
</section>
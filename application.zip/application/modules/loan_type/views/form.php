<div class="row">
	<div class="col-lg-12 col-md-12">		
		<?php 
                
                echo create_breadcrumb();		
                echo $this->session->flashdata('notify');
                
                ?>
	</div>
</div><!-- /.row -->

<?php echo form_open(site_url('loan_type/' . $action),'role="form" class="form-horizontal" id="form_loan_type" parsley-validate'); ?>               
<div class="panel panel-default">
    <div class="panel-heading"><i class="glyphicon glyphicon-signal"></i> </div>
     
      <div class="panel-body">
         
                       
               <div class="form-group">
                   <label for="name" class="col-sm-2 control-label">Name <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'name',
                                 'id'           => 'name',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Name',
                                 'maxlength'=>'255'
                                 ),
                                 set_value('name',$loan_type['name'])
                           );             
                  ?>
                 <?php echo form_error('name');?>
                </div>
              </div> <!--/ Name -->
                          
               <div class="form-group">
                   <label for="interest" class="col-sm-2 control-label">Interest <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'interest',
                                 'id'           => 'interest',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Interest',
                                 'maxlength'=>'20'
                                 ),
                                 set_value('interest',$loan_type['interest'])
                           );             
                  ?>
                 <?php echo form_error('interest');?>
                </div>
              </div> <!--/ Interest -->
               
           
      </div> <!--/ Panel Body -->
    <div class="panel-footer">   
          <div class="row"> 
              <div class="col-md-10 col-sm-12 col-md-offset-2 col-sm-offset-0">
                   <a href="<?php echo site_url('loan_type'); ?>" class="btn btn-default">
                       <i class="glyphicon glyphicon-chevron-left"></i> Back
                   </a> 
                    <button type="submit" class="btn btn-primary" name="post">
                        <i class="glyphicon glyphicon-floppy-save"></i> Save
                    </button>                  
              </div>
          </div>
    </div><!--/ Panel Footer -->       
</div><!--/ Panel -->
<?php echo form_close(); ?>  
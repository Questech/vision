<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of loan_type
 * @created on : Monday, 25-Jan-2016 04:06:42
 * @author DAUD D. SIMBOLON <daud.simbolon@gmail.com>
 * Copyright 2016    
 */
 
 
class loan_types extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }


    /**
     *  Get All data loan_type
     *
     *  @param limit  : Integer
     *  @param offset : Integer
     *
     *  @return array
     *
     */
    public function get_all($limit, $offset) 
    {

        $result = $this->db->get('loan_type', $limit, $offset);

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    

    /**
     *  Count All loan_type
     *    
     *  @return Integer
     *
     */
    public function count_all()
    {
        $this->db->from('loan_type');
        return $this->db->count_all_results();
    }
    

    /**
    * Search All loan_type
    *
    *  @param limit   : Integer
    *  @param offset  : Integer
    *  @param keyword : mixed
    *
    *  @return array
    *
    */
    public function get_search($limit, $offset) 
    {
        $keyword = $this->session->userdata('keyword');
                
        $this->db->like('name', $keyword);  
        
        $this->db->limit($limit, $offset);
        $result = $this->db->get('loan_type');

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    
    
    /**
    * Search All loan_type
    * @param keyword : mixed
    *
    * @return Integer
    *
    */
    public function count_all_search()
    {
        $keyword = $this->session->userdata('keyword');
        $this->db->from('loan_type');        
                
        $this->db->like('name', $keyword);  
        
        return $this->db->count_all_results();
    }


    
    
    
    /**
    *  Get One loan_type
    *
    *  @param id : Integer
    *
    *  @return array
    *
    */
    public function get_one($id) 
    {
        $this->db->where('id', $id);
        $result = $this->db->get('loan_type');

        if ($result->num_rows() == 1) 
        {
            return $result->row_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    /**
    *  Default form data loan_type
    *  @return array
    *
    */
    public function add()
    {
        $data = array(
            
                'name' => '',
            
                'interest' => '',
            
        );

        return $data;
    }

    
    
    
    
    /**
    *  Save data Post
    *
    *  @return void
    *
    */
    public function save() 
    {
        $data = array(
        
            'name' => strip_tags($this->input->post('name', TRUE)),
        
            'interest' => strip_tags($this->input->post('interest', TRUE)),
        
        );
        
        
        $this->db->insert('loan_type', $data);
    }
    
    
    

    
    /**
    *  Update modify data
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function update($id)
    {
        $data = array(
        
                'name' => strip_tags($this->input->post('name', TRUE)),
        
                'interest' => strip_tags($this->input->post('interest', TRUE)),
        
        );
        
        
        $this->db->where('id', $id);
        $this->db->update('loan_type', $data);
    }


    
    
    
    /**
    *  Delete data by id
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function destroy($id)
    {       
        $this->db->where('id', $id);
        $this->db->delete('loan_type');
        
    }







    



}

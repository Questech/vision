<div class="row">
	<div class="col-lg-12 col-md-12">		
		<?php 
                
                echo create_breadcrumb();		
                echo $this->session->flashdata('notify');
                
                ?>
	</div>
</div><!-- /.row -->

<section class="panel panel-default">
    <header class="panel-heading">
        <div class="row">
            <div class="col-md-8 col-xs-3">                
                <?php
                                  echo anchor(
                                           site_url('users/add'),
                                            '<i class="glyphicon glyphicon-plus"></i>',
                                            'class="btn btn-success btn-sm" data-tooltip="tooltip" data-placement="top" title="Add Member"'
                                          );
                 ?>
                
            </div>
            
        </div>
    </header>
    
    
    <div class="panel-body">
         <?php if ($userss) : ?>
          <table id="datatable" class="table table-hover table-condensed">
              
            <thead>
              <tr>
                <th class="header">#</th>
                
                    <th>Fisrt name</th>   
                
                    <th>Middle name</th>   
                
                    <th>Last name</th>   
                
                    <th>Id No</th>   
                
                    <th>Phone No</th>   
                
                <th class="red header" align="right" width="120">Action</th>
              </tr>
            </thead>
            
            
            <tbody>
             
               <?php foreach ($userss as $users) : ?>
              <tr>
              	<td><?php echo $number++;; ?> </td>
               
               <td><?php echo $users['fname']; ?></td>
               
               <td><?php echo $users['mname']; ?></td>
               
               <td><?php echo $users['lname']; ?></td>
               
               <td><?php echo $users['id_no']; ?></td>
               
               <td><?php echo $users['phn_no']; ?></td>
               
                <td>    
                    
                    <?php
                                  echo anchor(
                                          site_url('users/show/' . $users['id']),
                                            '<i class="glyphicon glyphicon-eye-open"></i>',
                                            'class="btn btn-sm btn-info" data-tooltip="tooltip" data-placement="top" title="Detail"'
                                          );
                   ?>
                    
                    <?php
                                  echo anchor(
                                          site_url('users/edit/' . $users['id']),
                                            '<i class="glyphicon glyphicon-edit"></i>',
                                            'class="btn btn-sm btn-success" data-tooltip="tooltip" data-placement="top" title="Edit"'
                                          );
                   ?>
                   
                   <?php
                                  echo anchor(
                                          site_url('users/destroy/' . $users['id']),
                                            '<i class="glyphicon glyphicon-trash"></i>',
                                            'onclick="return confirm(\'Confirm Delete..???\');" class="btn btn-sm btn-danger" data-tooltip="tooltip" data-placement="top" title="Delete"'
                                          );
                   ?>   
                                 
                </td>
              </tr>     
               <?php endforeach; ?>
            </tbody>
          </table>
          <?php else: ?>
                <?php  echo notify('Data members not available','info');?>
          <?php endif; ?>
    </div>
    
    
    <div class="panel-footer">
        <div class="row">
           <div class="col-md-3">
               Users
               <span class="label label-info">
                    <?php echo $total; ?>
               </span>
           </div>  
           <div class="col-md-9">
                 <?php echo $pagination; ?>
           </div>
        </div>
    </div>
</section>
<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of users
 * @created on : Friday, 29-Jan-2016 06:19:56
 * @author DAUD D. SIMBOLON <daud.simbolon@gmail.com>
 * Copyright 2016    
 */
 
 
class userss extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }


    /**
     *  Get All data users
     *
     *  @param limit  : Integer
     *  @param offset : Integer
     *
     *  @return array
     *
     */
    public function get_all($limit, $offset) 
    {

        $result = $this->db->get('users', $limit, $offset);

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    

    /**
     *  Count All users
     *    
     *  @return Integer
     *
     */
    public function count_all()
    {
        $this->db->from('users');
        return $this->db->count_all_results();
    }
    

    /**
    * Search All users
    *
    *  @param limit   : Integer
    *  @param offset  : Integer
    *  @param keyword : mixed
    *
    *  @return array
    *
    */
    public function get_search($limit, $offset) 
    {
        $keyword = $this->session->userdata('keyword');
                
        $this->db->like('fname', $keyword);  
                
        $this->db->like('mname', $keyword);  
                
        $this->db->like('lname', $keyword);  
        
        $this->db->limit($limit, $offset);
        $result = $this->db->get('users');

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    
    
    /**
    * Search All users
    * @param keyword : mixed
    *
    * @return Integer
    *
    */
    public function count_all_search()
    {
        $keyword = $this->session->userdata('keyword');
        $this->db->from('users');        
                
        $this->db->like('fname', $keyword);  
                
        $this->db->like('mname', $keyword);  
                
        $this->db->like('lname', $keyword);  
        
        return $this->db->count_all_results();
    }


    
    
    
    /**
    *  Get One users
    *
    *  @param id : Integer
    *
    *  @return array
    *
    */
    public function get_one($id) 
    {
        $this->db->where('id', $id);
        $result = $this->db->get('users');

        if ($result->num_rows() == 1) 
        {
            return $result->row_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    /**
    *  Default form data users
    *  @return array
    *
    */
    public function add()
    {
        $data = array(
            
                'fname' => '',
            
                'mname' => '',
            
                'lname' => '',
            
                'id_no' => '',
            
                'phn_no' => '',
            
        );

        return $data;
    }

    
    
    
    
    /**
    *  Save data Post
    *
    *  @return void
    *
    */
    public function save() 
    {
        $data = array(
        
            'fname' => strip_tags($this->input->post('fname', TRUE)),
        
            'mname' => strip_tags($this->input->post('mname', TRUE)),
        
            'lname' => strip_tags($this->input->post('lname', TRUE)),
        
            'id_no' => strip_tags($this->input->post('id_no', TRUE)),
        
            'phn_no' => strip_tags($this->input->post('phn_no', TRUE)),
        
        );
        
        
        $this->db->insert('users', $data);
    }
    
    
    

    
    /**
    *  Update modify data
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function update($id)
    {
        $data = array(
        
                'fname' => strip_tags($this->input->post('fname', TRUE)),
        
                'mname' => strip_tags($this->input->post('mname', TRUE)),
        
                'lname' => strip_tags($this->input->post('lname', TRUE)),
        
                'id_no' => strip_tags($this->input->post('id_no', TRUE)),
        
                'phn_no' => strip_tags($this->input->post('phn_no', TRUE)),
        
        );
        
        
        $this->db->where('id', $id);
        $this->db->update('users', $data);
    }


    
    
    
    /**
    *  Delete data by id
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function destroy($id)
    {       
        $this->db->where('id', $id);
        $this->db->delete('users');
        
    }







    



}

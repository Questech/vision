<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Vision | SHG </title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->

    <!-- Font Awesome -->
   <link href="<?php echo base_url(); ?>assets/font-awesome-4.4.0/css/font-awesome.css" rel="stylesheet" type="text/css">    <!-- Ionicons -->
   
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/login.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script> 
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

      <div class="container">         

        <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">   
          <center> <div class="col-md-4"></div>    </center>               
            <div class="panel panel-info" >
                    <div class="panel-heading">
                        <div class="panel-title"><img class="img-responsive" src="<?php echo base_url(); ?>assets/img/visionlogo1.png"></div>

                        <div style="float:right; font-size: 80%; position: relative; top:-10px"><a href="#">Forgot password?</a></div>
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >

                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                           <div> 
                      
                           <?php $attributes = array('class' => 'form-horizontal'); ?>
                           <?php echo form_open('membership/validate_credentials', $attributes); ?> 

                                 <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="login-username" type="text" class="form-control" name="email" value="" placeholder="username">                                        
                                  </div>
                                
                                  <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input id="login-password" type="password" class="form-control" name="password" placeholder="password">
                                  </div>
                                    
                                  
                                    <?php
                                        if(isset($message_error) && $message_error){
                                      echo '<div class="alert alert-error">';
                                        echo '<a class="close" data-dismiss="alert">×</a>';
                                        echo '<strong>Oh snap!</strong> Change a few things up and try submitting again.';
                                      echo '</div>';             
                                  }
                                    ?>
                                
                                  <div class="i nput-group">
                                      <div class="checkbox">
                                        <label>
                                          <input id="login-remember" type="checkbox" name="remember" value="1"> Remember me
                                        </label>
                                      </div>
                                  </div>


                                <div style="margin-top:10px" class="form-group">
                                    <!-- Button -->

                                    <div class="col-sm-12 controls">
                                   <?php  echo form_submit('submit', 'Login', 'class="btn btn-block btn-large btn-success"'); ?>

                                    </div>
                                </div>                                
                            </div>
                        </div>                     
                    </div>  
                  </div>      
             
       </div>
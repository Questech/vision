<div class="row">
	<div class="col-lg-12 col-md-12">		
		<?php 
                
                echo create_breadcrumb();		
                echo $this->session->flashdata('notify');
                
                ?>
	</div>
</div><!-- /.row -->

<?php echo form_open(site_url('users/' . $action),'role="form" class="form-horizontal" id="form_users" parsley-validate'); ?>               
<div class="panel panel-default">
    <div class="panel-heading"><i class="glyphicon glyphicon-signal"></i> </div>
     
      <div class="panel-body">
         
                       
               <div class="form-group">
                   <label for="fname" class="col-sm-2 control-label">Fname <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'fname',
                                 'id'           => 'fname',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Fname',
                                 'maxlength'=>'255'
                                 ),
                                 set_value('fname',$users['fname'])
                           );             
                  ?>
                 <?php echo form_error('fname');?>
                </div>
              </div> <!--/ Fname -->
                          
               <div class="form-group">
                   <label for="mname" class="col-sm-2 control-label">Mname <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'mname',
                                 'id'           => 'mname',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Mname',
                                 'maxlength'=>'255'
                                 ),
                                 set_value('mname',$users['mname'])
                           );             
                  ?>
                 <?php echo form_error('mname');?>
                </div>
              </div> <!--/ Mname -->
                          
               <div class="form-group">
                   <label for="lname" class="col-sm-2 control-label">Lname <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'lname',
                                 'id'           => 'lname',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Lname',
                                 'maxlength'=>'255'
                                 ),
                                 set_value('lname',$users['lname'])
                           );             
                  ?>
                 <?php echo form_error('lname');?>
                </div>
              </div> <!--/ Lname -->
                          
               <div class="form-group">
                   <label for="id_no" class="col-sm-2 control-label">Id No <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'id_no',
                                 'id'           => 'id_no',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Id No',
                                 'maxlength'=>'20'
                                 ),
                                 set_value('id_no',$users['id_no'])
                           );             
                  ?>
                 <?php echo form_error('id_no');?>
                </div>
              </div> <!--/ Id No -->
                          
               <div class="form-group">
                   <label for="phn_no" class="col-sm-2 control-label">Phn No <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'phn_no',
                                 'id'           => 'phn_no',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Phn No',
                                 'maxlength'=>'20'
                                 ),
                                 set_value('phn_no',$users['phn_no'])
                           );             
                  ?>
                 <?php echo form_error('phn_no');?>
                </div>
              </div> <!--/ Phn No -->
               
           
      </div> <!--/ Panel Body -->
    <div class="panel-footer">   
          <div class="row"> 
              <div class="col-md-10 col-sm-12 col-md-offset-2 col-sm-offset-0">
                   <a href="<?php echo site_url('users'); ?>" class="btn btn-default">
                       <i class="glyphicon glyphicon-chevron-left"></i> Back
                   </a> 
                    <button type="submit" class="btn btn-primary" name="post">
                        <i class="glyphicon glyphicon-floppy-save"></i> Save
                    </button>                  
              </div>
          </div>
    </div><!--/ Panel Footer -->       
</div><!--/ Panel -->
<?php echo form_close(); ?>  
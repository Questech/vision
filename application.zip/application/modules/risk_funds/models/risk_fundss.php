<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of risk_funds
 * @created on : Monday, 25-Jan-2016 02:58:07
 * @author DAUD D. SIMBOLON <daud.simbolon@gmail.com>
 * Copyright 2016    
 */
 
 
class risk_fundss extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }


    /**
     *  Get All data risk_funds
     *
     *  @param limit  : Integer
     *  @param offset : Integer
     *
     *  @return array
     *
     */
    public function get_all($limit, $offset) 
    {

        $result = $this->db->get('risk_funds', $limit, $offset);

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    

    /**
     *  Count All risk_funds
     *    
     *  @return Integer
     *
     */
    public function count_all()
    {
        $this->db->from('risk_funds');
        return $this->db->count_all_results();
    }
    

    /**
    * Search All risk_funds
    *
    *  @param limit   : Integer
    *  @param offset  : Integer
    *  @param keyword : mixed
    *
    *  @return array
    *
    */
    public function get_search($limit, $offset) 
    {
        $keyword = $this->session->userdata('keyword');
                
        $this->db->like('user', $keyword);  
        
        $this->db->limit($limit, $offset);
        $result = $this->db->get('risk_funds');

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    
    
    /**
    * Search All risk_funds
    * @param keyword : mixed
    *
    * @return Integer
    *
    */
    public function count_all_search()
    {
        $keyword = $this->session->userdata('keyword');
        $this->db->from('risk_funds');        
                
        $this->db->like('user', $keyword);  
        
        return $this->db->count_all_results();
    }


    
    
    
    /**
    *  Get One risk_funds
    *
    *  @param id : Integer
    *
    *  @return array
    *
    */
    public function get_one($id) 
    {
        $this->db->where('id', $id);
        $result = $this->db->get('risk_funds');

        if ($result->num_rows() == 1) 
        {
            return $result->row_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    /**
    *  Default form data risk_funds
    *  @return array
    *
    */
    public function add()
    {
        $data = array(
            
                'user' => '',
            
                'loan_amount' => '',
            
                'risk_fund' => '',
            
        );

        return $data;
    }

    
    
    
    
    /**
    *  Save data Post
    *
    *  @return void
    *
    */
    public function save() 
    {
        $data = array(
        
            'user' => strip_tags($this->input->post('user', TRUE)),
        
            'loan_amount' => strip_tags($this->input->post('loan_amount', TRUE)),
        
            'risk_fund' => strip_tags($this->input->post('risk_fund', TRUE)),
        
        );
        
        
        $this->db->insert('risk_funds', $data);
    }
    
    
    

    
    /**
    *  Update modify data
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function update($id)
    {
        $data = array(
        
                'user' => strip_tags($this->input->post('user', TRUE)),
        
                'loan_amount' => strip_tags($this->input->post('loan_amount', TRUE)),
        
                'risk_fund' => strip_tags($this->input->post('risk_fund', TRUE)),
        
        );
        
        
        $this->db->where('id', $id);
        $this->db->update('risk_funds', $data);
    }


    
    
    
    /**
    *  Delete data by id
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function destroy($id)
    {       
        $this->db->where('id', $id);
        $this->db->delete('risk_funds');
        
    }







    
    
    // get users
    public function get_users() 
    {
      
        $result = $this->db->get('users')
                           ->result();

        $ret ['']= 'Pilih Users :';
        if($result)
        {
            foreach ($result as $key => $row)
            {
                $ret [$row->id] = $row->fname;
            }
        }
        
        return $ret;
    }


    



}

<div class="row">
	<div class="col-lg-12 col-md-12">		
		<?php 
                
                echo create_breadcrumb();		
                echo $this->session->flashdata('notify');
                
                ?>
	</div>
</div><!-- /.row -->

<?php echo form_open(site_url('risk_funds/' . $action),'role="form" class="form-horizontal" id="form_risk_funds" parsley-validate'); ?>               
<div class="panel panel-default">
    <div class="panel-heading"><i class="glyphicon glyphicon-signal"></i> </div>
     
      <div class="panel-body">
         
                       
               <div class="form-group">
                   <label for="user" class="col-sm-2 control-label">User <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_dropdown(
                           'users',
                           $users,  
                           set_value('user',$risk_funds['user']),
                           'class="form-control input-sm  required"  id="user"'
                           );             
                  ?>
                 <?php echo form_error('user');?>
                </div>
              </div> <!--/ User -->
                          
               <div class="form-group">
                   <label for="loan_amount" class="col-sm-2 control-label">Loan Amount <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'loan_amount',
                                 'id'           => 'loan_amount',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Loan Amount',
                                 'maxlength'=>'20'
                                 ),
                                 set_value('loan_amount',$risk_funds['loan_amount'])
                           );             
                  ?>
                 <?php echo form_error('loan_amount');?>
                </div>
              </div> <!--/ Loan Amount -->
                          
               <div class="form-group">
                   <label for="risk_fund" class="col-sm-2 control-label">Risk Fund <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'risk_fund',
                                 'id'           => 'risk_fund',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Risk Fund',
                                 'maxlength'=>'20'
                                 ),
                                 set_value('risk_fund',$risk_funds['risk_fund'])
                           );             
                  ?>
                 <?php echo form_error('risk_fund');?>
                </div>
              </div> <!--/ Risk Fund -->
               
           
      </div> <!--/ Panel Body -->
    <div class="panel-footer">   
          <div class="row"> 
              <div class="col-md-10 col-sm-12 col-md-offset-2 col-sm-offset-0">
                   <a href="<?php echo site_url('risk_funds'); ?>" class="btn btn-default">
                       <i class="glyphicon glyphicon-chevron-left"></i> Back
                   </a> 
                    <button type="submit" class="btn btn-primary" name="post">
                        <i class="glyphicon glyphicon-floppy-save"></i> Save                    </button>                  
              </div>
          </div>
    </div><!--/ Panel Footer -->       
</div><!--/ Panel -->
<?php echo form_close(); ?>  
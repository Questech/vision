<?php if (!defined('BASEPATH'))  exit('No direct script access allowed');

/**
 * Controller risk_funds
 * @created on : Monday, 25-Jan-2016 02:58:07
 * @author Daud D. Simbolon <daud.simbolon@gmail.com>
 * Copyright 2016
 *
 *
 */


class risk_funds extends MY_Controller
{

    public function __construct() 
    {
        parent::__construct();         
        $this->load->model('risk_fundss');

         if(!$this->session->userdata('is_logged_in')){
            redirect('/');
    }
    
}
    /**
    * List all data risk_funds
    *
    */
    public function index() 
    {
        $config = array(
            'base_url'          => site_url('risk_funds/index/'),
            'total_rows'        => $this->risk_fundss->count_all(),
            'per_page'          => $this->config->item('per_page'),
            'uri_segment'       => 3,
            'num_links'         => 9,
            'use_page_numbers'  => FALSE
            
        );
        
        $this->pagination->initialize($config);
        $data['total']          = $config['total_rows'];
        $data['pagination']     = $this->pagination->create_links();
        $data['number']         = (int)$this->uri->segment(3) +1;
        $data['risk_fundss']       = $this->risk_fundss->get_all($config['per_page'], $this->uri->segment(3));
        $this->template->render('risk_funds/view',$data);
	      
    }

    

    /**
    * Call Form to Add  New risk_funds
    *
    */
    public function add() 
    {       
        $data['risk_funds'] = $this->risk_fundss->add();
        $data['action']  = 'risk_funds/save';
     
       $data['users'] = $this->risk_fundss->get_users();
     
        $this->template->js_add('
                $(document).ready(function(){
                // binds form submission and fields to the validation engine
                $("#form_risk_funds").parsley();
                        });','embed');
      
        $this->template->render('risk_funds/form',$data);

    }

    

    /**
    * Call Form to Modify risk_funds
    *
    */
    public function edit($id='') 
    {
        if ($id != '') 
        {

            $data['risk_funds']      = $this->risk_fundss->get_one($id);
            $data['action']       = 'risk_funds/save/' . $id;           
      
           $data['users'] = $this->risk_fundss->get_users();
       
            $this->template->js_add('
                     $(document).ready(function(){
                    // binds form submission and fields to the validation engine
                    $("#form_risk_funds").parsley();
                                    });','embed');
            
            $this->template->render('risk_funds/form',$data);
            
        }
        else 
        {
            $this->session->set_flashdata('notif', notify('Data tidak ditemukan','info'));
            redirect(site_url('risk_funds'));
        }
    }


    
    /**
    * Save & Update data  risk_funds
    *
    */
    public function save($id =NULL) 
    {
        // validation config
        $config = array(
                  
                    array(
                        'field' => 'user',
                        'label' => 'User',
                        'rules' => 'trim|xss_clean|required'
                        ),
                    
                    array(
                        'field' => 'loan_amount',
                        'label' => 'Loan Amount',
                        'rules' => 'trim|xss_clean|required'
                        ),
                    
                    array(
                        'field' => 'risk_fund',
                        'label' => 'Risk Fund',
                        'rules' => 'trim|xss_clean|required'
                        ),
                               
                  );
            
        // if id NULL then add new data
        if(!$id)
        {    
                  $this->form_validation->set_rules($config);

                  if ($this->form_validation->run() == TRUE) 
                  {
                      if ($this->input->post()) 
                      {
                          
                          $this->risk_fundss->save();
                          $this->session->set_flashdata('notif', notify('Data berhasil di simpan','success'));
                          redirect('risk_funds');
                      }
                  } 
                  else // If validation incorrect 
                  {
                      $this->add();
                  }
         }
         else // Update data if Form Edit send Post and ID available
         {               
                $this->form_validation->set_rules($config);

                if ($this->form_validation->run() == TRUE) 
                {
                    if ($this->input->post()) 
                    {
                        $this->risk_fundss->update($id);
                        $this->session->set_flashdata('notif', notify('Data berhasil di update','success'));
                        redirect('risk_funds');
                    }
                } 
                else // If validation incorrect 
                {
                    $this->edit($id);
                }
         }
    }

    
    
    /**
    * Detail risk_funds
    *
    */
    public function show($id='') 
    {
        if ($id != '') 
        {

            $data['risk_funds'] = $this->risk_fundss->get_one($id);            
            $this->template->render('risk_funds/_show',$data);
            
        }
        else 
        {
            $this->session->set_flashdata('notif', notify('Data tidak ditemukan','info'));
            redirect(site_url('risk_funds'));
        }
    }
    
    
    /**
    * Search risk_funds like ""
    *
    */   
    public function search()
    {
        if($this->input->post('q'))
        {
            $keyword = $this->input->post('q');
            
            $this->session->set_userdata(
                        array('keyword' => $this->input->post('q',TRUE))
                    );
        }
        
         $config = array(
            'base_url'          => site_url('risk_funds/search/'),
            'total_rows'        => $this->risk_fundss->count_all_search(),
            'per_page'          => $this->config->item('per_page'),
            'uri_segment'       => 3,
            'num_links'         => 9,
            'use_page_numbers'  => FALSE
        );
        
        $this->pagination->initialize($config);
        $data['total']          = $config['total_rows'];
        $data['number']         = (int)$this->uri->segment(3) +1;
        $data['pagination']     = $this->pagination->create_links();
        $data['risk_fundss']       = $this->risk_fundss->get_search($config['per_page'], $this->uri->segment(3));
       
        $this->template->render('risk_funds/view',$data);
    }
    
    
    /**
    * Delete risk_funds by ID
    *
    */
    public function destroy($id) 
    {        
        if ($id) 
        {
            $this->risk_fundss->destroy($id);           
             $this->session->set_flashdata('notif', notify('Data berhasil di hapus','success'));
             redirect('risk_funds');
        } 
        else 
        {
            $this->session->set_flashdata('notif', notify('Data tidak ditemukan','warning'));
            redirect('risk_funds');
        }       
    }

}

?>

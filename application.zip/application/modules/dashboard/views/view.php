<div class="jumbotron">
  <img src="<?php echo base_url() ;?>assets/img/bg.jpg " class="img-responsive">
        
</div>
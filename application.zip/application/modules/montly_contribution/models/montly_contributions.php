<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of montly_contribution
 * @created on : Monday, 25-Jan-2016 03:14:38
 * @author DAUD D. SIMBOLON <daud.simbolon@gmail.com>
 * Copyright 2016    
 */
 
 
class montly_contributions extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }


    /**
     *  Get All data montly_contribution
     *
     *  @param limit  : Integer
     *  @param offset : Integer
     *
     *  @return array
     *
     */
    public function get_all($limit, $offset) 
    {

        $result = $this->db->get('montly_contribution', $limit, $offset);

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    

    /**
     *  Count All montly_contribution
     *    
     *  @return Integer
     *
     */
    public function count_all()
    {
        $this->db->from('montly_contribution');
        return $this->db->count_all_results();
    }
    

    /**
    * Search All montly_contribution
    *
    *  @param limit   : Integer
    *  @param offset  : Integer
    *  @param keyword : mixed
    *
    *  @return array
    *
    */
    public function get_search($limit, $offset) 
    {
        $keyword = $this->session->userdata('keyword');
                
        $this->db->like('month', $keyword);  
                
        $this->db->like('user', $keyword);  
        
        $this->db->limit($limit, $offset);
        $result = $this->db->get('montly_contribution');

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    
    
    /**
    * Search All montly_contribution
    * @param keyword : mixed
    *
    * @return Integer
    *
    */
    public function count_all_search()
    {
        $keyword = $this->session->userdata('keyword');
        $this->db->from('montly_contribution');        
                
        $this->db->like('month', $keyword);  
                
        $this->db->like('user', $keyword);  
        
        return $this->db->count_all_results();
    }


    
    
    
    /**
    *  Get One montly_contribution
    *
    *  @param id : Integer
    *
    *  @return array
    *
    */
    public function get_one($id) 
    {
        $this->db->where('id', $id);
        $result = $this->db->get('montly_contribution');

        if ($result->num_rows() == 1) 
        {
            return $result->row_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    /**
    *  Default form data montly_contribution
    *  @return array
    *
    */
    public function add()
    {
        $data = array(
            
                'month' => '',
            
                'amount' => '',
            
                'user' => '',
            
        );

        return $data;
    }

    
    
    
    
    /**
    *  Save data Post
    *
    *  @return void
    *
    */
    public function save() 
    {
        $data = array(
        
            'month' => strip_tags($this->input->post('month', TRUE)),
        
            'amount' => strip_tags($this->input->post('amount', TRUE)),
        
            'user' => strip_tags($this->input->post('user', TRUE)),
        
        );
        
        
        $this->db->insert('montly_contribution', $data);
    }
    
    
    

    
    /**
    *  Update modify data
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function update($id)
    {
        $data = array(
        
                'month' => strip_tags($this->input->post('month', TRUE)),
        
                'amount' => strip_tags($this->input->post('amount', TRUE)),
        
                'user' => strip_tags($this->input->post('user', TRUE)),
        
        );
        
        
        $this->db->where('id', $id);
        $this->db->update('montly_contribution', $data);
    }


    
    
    
    /**
    *  Delete data by id
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function destroy($id)
    {       
        $this->db->where('id', $id);
        $this->db->delete('montly_contribution');
        
    }







    
    
    // get users
    public function get_users() 
    {
      
        $result = $this->db->get('users')
                           ->result();

        $ret ['']= 'Select Users :';
        if($result)
        {
            foreach ($result as $key => $row)
            {
                $ret [$row->fname] = $row->fname;
            }
        }
        
        return $ret;
    }


    



}

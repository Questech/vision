<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of add_loan
 * @created on : Monday, 25-Jan-2016 05:29:00
 * @author DAUD D. SIMBOLON <daud.simbolon@gmail.com>
 * Copyright 2016    
 */
 
 
class add_loans extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }


    /**
     *  Get All data add_loan
     *
     *  @param limit  : Integer
     *  @param offset : Integer
     *
     *  @return array
     *
     */
    public function get_all($limit, $offset) 
    {

        $result = $this->db->get('add_loan', $limit, $offset);

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    

    /**
     *  Count All add_loan
     *    
     *  @return Integer
     *
     */
    public function count_all()
    {
        $this->db->from('add_loan');
        return $this->db->count_all_results();
    }
    

    /**
    * Search All add_loan
    *
    *  @param limit   : Integer
    *  @param offset  : Integer
    *  @param keyword : mixed
    *
    *  @return array
    *
    */
    public function get_search($limit, $offset) 
    {
        $keyword = $this->session->userdata('keyword');
                
        $this->db->like('user', $keyword);  
                
        $this->db->like('date', $keyword);  
                
        $this->db->like('ltype', $keyword);  
        
        $this->db->limit($limit, $offset);
        $result = $this->db->get('add_loan');

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    
    
    /**
    * Search All add_loan
    * @param keyword : mixed
    *
    * @return Integer
    *
    */
    public function count_all_search()
    {
        $keyword = $this->session->userdata('keyword');
        $this->db->from('add_loan');        
                
        $this->db->like('user', $keyword);  
                
        $this->db->like('date', $keyword);  
                
        $this->db->like('ltype', $keyword);  
        
        return $this->db->count_all_results();
    }


    
    
    
    /**
    *  Get One add_loan
    *
    *  @param id : Integer
    *
    *  @return array
    *
    */
    public function get_one($id) 
    {
        $this->db->where('id', $id);
        $result = $this->db->get('add_loan');

        if ($result->num_rows() == 1) 
        {
            return $result->row_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    /**
    *  Default form data add_loan
    *  @return array
    *
    */
    public function add()
    {
        $data = array(
            
                'user' => '',
            
                'date' => '',
            
                'ltype' => '',
            
                'borrowed' => '',
            
                'amount_to_pay' => '',
            
                'paid' => '',
            
                'remaing' => '',
            
                'riskfund' => '',
            
        );

        return $data;
    }

    
    
    
    
    /**
    *  Save data Post
    *
    *  @return void
    *
    */
    public function save() 
    {
        $borrowed = $this->input->post('borrowed');
        $amount_to_pay = 1.1*$borrowed;
        $riskfund = 0.02*$borrowed;
        $remaining = $amount_to_pay;

        $data = array(
        
            'user' => strip_tags($this->input->post('user', TRUE)),
        
            'date' => strip_tags($this->input->post('date', TRUE)),
        
            'ltype' => strip_tags($this->input->post('ltype', TRUE)),
        
            'borrowed' => strip_tags($this->input->post('borrowed', TRUE)),
        
            'amount_to_pay' => $amount_to_pay,
        
            'paid' => 0,
        
            'remaing' => $amount_to_pay,
        
            'riskfund' => $riskfund,
        
        );
        
        
        $this->db->insert('add_loan', $data);
    }

    
    /**
    *  Update modify data
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function update($id)
    {
        $data = array(
        
                'user' => strip_tags($this->input->post('user', TRUE)),
        
                'date' => strip_tags($this->input->post('date', TRUE)),
        
                'ltype' => strip_tags($this->input->post('ltype', TRUE)),
        
                'borrowed' => strip_tags($this->input->post('borrowed', TRUE)),
        
                'amount_to_pay' => strip_tags($this->input->post('amount_to_pay', TRUE)),
        
                'paid' => strip_tags($this->input->post('paid', TRUE)),
        
                'remaing' => strip_tags($this->input->post('remaing', TRUE)),
        
                'riskfund' => strip_tags($this->input->post('riskfund', TRUE)),
        
        );
        
        
        $this->db->where('id', $id);
        $this->db->update('add_loan', $data);
    }


    
    
    
    /**
    *  Delete data by id
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function destroy($id)
    {       
        $this->db->where('id', $id);
        $this->db->delete('add_loan');
        
    }







    
    
    // get users
    public function get_users() 
    {
      
        $result = $this->db->get('users')
                           ->result();

        $ret ['']= 'Pilih Users :';
        if($result)
        {
            foreach ($result as $key => $row)
            {
                $ret [$row->fname] = $row->fname;
            }
        }
        
        return $ret;
    }


    
    
    // get loan_type
    public function get_loan_type() 
    {
      
        $result = $this->db->get('loan_type')
                           ->result();

        $ret ['']= 'Pilih Loan Type :';
        if($result)
        {
            foreach ($result as $key => $row)
            {
                $ret [$row->name] = $row->name;
            }
        }
        
        return $ret;
    }


    



}

<?php if (!defined('BASEPATH'))  exit('No direct script access allowed');




class add_loan extends MY_Controller
{

    public function __construct() 
    {
        parent::__construct();         
        $this->load->model('add_loans');

        if(!$this->session->userdata('is_logged_in')){
            redirect('/');
        }
    }

 

    /**
    * List all data add_loan
    *
    */
    public function index() 
    {
        $config = array(
            'base_url'          => site_url('add_loan/index/'),
            'total_rows'        => $this->add_loans->count_all(),
            'per_page'          => $this->config->item('per_page'),
            'uri_segment'       => 3,
            'num_links'         => 9,
            'use_page_numbers'  => FALSE
            
        );
        
        $this->pagination->initialize($config);
        $data['total']          = $config['total_rows'];
        $data['pagination']     = $this->pagination->create_links();
        $data['number']         = (int)$this->uri->segment(3) +1;
        $data['add_loans']       = $this->add_loans->get_all($config['per_page'], $this->uri->segment(3));
        $this->template->render('add_loan/view',$data);
	      
    }

    

    /**
    * Call Form to Add  New add_loan
    *
    */
    public function add() 
    {       
        $data['add_loan'] = $this->add_loans->add();
        $data['action']  = 'add_loan/save';
     
       $data['users'] = $this->add_loans->get_users();
     
       $data['loan_type'] = $this->add_loans->get_loan_type();
     
        $this->template->js_add('
                $(document).ready(function(){
                // binds form submission and fields to the validation engine
                $("#form_add_loan").parsley();
                        });','embed');
      
        $this->template->render('add_loan/form',$data);

    }

    

    /**
    * Call Form to Modify add_loan
    *
    */
    public function edit($id='') 
    {
        if ($id != '') 
        {

            $data['add_loan']      = $this->add_loans->get_one($id);
            $data['action']       = 'add_loan/save/' . $id;           
      
           $data['users'] = $this->add_loans->get_users();
       
           $data['loan_type'] = $this->add_loans->get_loan_type();
       
            $this->template->js_add('
                     $(document).ready(function(){
                    // binds form submission and fields to the validation engine
                    $("#form_add_loan").parsley();
                                    });','embed');
            
            $this->template->render('add_loan/form',$data);
            
        }
        else 
        {
            $this->session->set_flashdata('notif', notify('Data tidak ditemukan','info'));
            redirect(site_url('add_loan'));
        }
    }


    
    /**
    * Save & Update data  add_loan
    *
    */
    public function save($id =NULL) 
    {
        // validation config
        $config = array(
                  
                    array(
                        'field' => 'user',
                        'label' => 'User',
                        'rules' => 'trim|xss_clean|required'
                        ),
                    
                    array(
                        'field' => 'date',
                        'label' => 'Date',
                        'rules' => 'trim|xss_clean|required'
                        ),
                    
                    array(
                        'field' => 'ltype',
                        'label' => 'Ltype',
                        'rules' => 'trim|xss_clean|required'
                        ),
                    
                    array(
                        'field' => 'borrowed',
                        'label' => 'Borrowed',
                        'rules' => 'trim|xss_clean|required'
                        ),
                    
                    array(
                        'field' => 'amount_to_pay',
                        'label' => 'Amount To Pay',
                        'rules' => 'trim|xss_clean'
                        ),
                    
                    array(
                        'field' => 'paid',
                        'label' => 'Paid',
                        'rules' => 'trim|xss_clean'
                        ),
                    
                    array(
                        'field' => 'remaing',
                        'label' => 'Remaing',
                        'rules' => 'trim|xss_clean'
                        ),
                    
                    array(
                        'field' => 'riskfund',
                        'label' => 'Riskfund',
                        'rules' => 'trim|xss_clean'
                        ),
                               
                  );
            
        // if id NULL then add new data
        if(!$id)
        {    
                  $this->form_validation->set_rules($config);

                  if ($this->form_validation->run() == TRUE) 
                  {
                      if ($this->input->post()) 
                      {
                          
                          $this->add_loans->save();
                          $this->session->set_flashdata('notif', notify('Data berhasil di simpan','success'));
                          redirect('add_loan');
                      }
                  } 
                  else // If validation incorrect 
                  {
                      $this->add();
                  }
         }
         else // Update data if Form Edit send Post and ID available
         {               
                $this->form_validation->set_rules($config);

                if ($this->form_validation->run() == TRUE) 
                {
                    if ($this->input->post()) 
                    {
                        $this->add_loans->update($id);
                        $this->session->set_flashdata('notif', notify('Data berhasil di update','success'));
                        redirect('add_loan');
                    }
                } 
                else // If validation incorrect 
                {
                    $this->edit($id);
                }
         }
    }

    
    
    /**
    * Detail add_loan
    *
    */
    public function show($id='') 
    {
        if ($id != '') 
        {

            $data['add_loan'] = $this->add_loans->get_one($id);            
            $this->template->render('add_loan/_show',$data);
            
        }
        else 
        {
            $this->session->set_flashdata('notif', notify('Data tidak ditemukan','info'));
            redirect(site_url('add_loan'));
        }
    }
    
    
    /**
    * Search add_loan like ""
    *
    */   
    public function search()
    {
        if($this->input->post('q'))
        {
            $keyword = $this->input->post('q');
            
            $this->session->set_userdata(
                        array('keyword' => $this->input->post('q',TRUE))
                    );
        }
        
         $config = array(
            'base_url'          => site_url('add_loan/search/'),
            'total_rows'        => $this->add_loans->count_all_search(),
            'per_page'          => $this->config->item('per_page'),
            'uri_segment'       => 3,
            'num_links'         => 9,
            'use_page_numbers'  => FALSE
        );
        
        $this->pagination->initialize($config);
        $data['total']          = $config['total_rows'];
        $data['number']         = (int)$this->uri->segment(3) +1;
        $data['pagination']     = $this->pagination->create_links();
        $data['add_loans']       = $this->add_loans->get_search($config['per_page'], $this->uri->segment(3));
       
        $this->template->render('add_loan/view',$data);
    }
    
    
    /**
    * Delete add_loan by ID
    *
    */
    public function destroy($id) 
    {        
        if ($id) 
        {
            $this->add_loans->destroy($id);           
             $this->session->set_flashdata('notif', notify('Data berhasil di hapus','success'));
             redirect('add_loan');
        } 
        else 
        {
            $this->session->set_flashdata('notif', notify('Data tidak ditemukan','warning'));
            redirect('add_loan');
        }       
    }

}

?>

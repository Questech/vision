<div class="row">
	<div class="col-lg-12 col-md-12">		
		<?php 
                
                echo create_breadcrumb();		
                echo $this->session->flashdata('notify');
                
                ?>
	</div>
</div><!-- /.row -->

<?php echo form_open(site_url('add_loan/' . $action),'role="form" class="form-horizontal" id="form_add_loan" parsley-validate'); ?>               
<div class="panel panel-default">
    <div class="panel-heading"><i class="glyphicon glyphicon-signal"></i> </div>
     
      <div class="panel-body">
         
                       
               <div class="form-group">
                   <label for="user" class="col-sm-2 control-label">User <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_dropdown(
                           'user',
                           $users,  
                           set_value('user',$add_loan['user']),
                           'class="form-control input-sm  required"  id="user"'
                           );             
                  ?>
                 <?php echo form_error('user');?>
                </div>
              </div> <!--/ User -->
                          
               <div class="form-group">
                   <label for="date" class="col-sm-2 control-label">Date <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'date',
                                 'id'           => 'date',                       
                                 'class'        => 'form-control input-sm tanggal  required',
                                 'placeholder'  => 'Date',
                                 'maxlength'=>'20'
                                 ),
                                 set_value('date',$add_loan['date'])
                           );             
                  ?>
                 <?php echo form_error('date');?>
                </div>
              </div> <!--/ Date -->
                          
               <div class="form-group">
                   <label for="ltype" class="col-sm-2 control-label">Loan Type <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_dropdown(
                           'ltype',
                           $loan_type,  
                           set_value('ltype',$add_loan['ltype']),
                           'class="form-control input-sm  required"  id="ltype"'
                           );             
                  ?>
                 <?php echo form_error('ltype');?>
                </div>
              </div> <!--/ Ltype -->
                          
               <div class="form-group">
                   <label for="borrowed" class="col-sm-2 control-label">Amount Borrowed <span class="required-input">*</span></label>
                <div class="col-sm-6">                                   
                  <?php                  
                   echo form_input(
                                array(
                                 'name'         => 'borrowed',
                                 'id'           => 'borrowed',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Borrowed',
                                 'maxlength'=>'20'
                                 ),
                                 set_value('borrowed',$add_loan['borrowed'])
                           );             
                  ?>
                 <?php echo form_error('borrowed');?>
                </div>
              </div> <!--/ Borrowed -->
               
           
      </div> <!--/ Panel Body -->
    <div class="panel-footer">   
          <div class="row"> 
              <div class="col-md-10 col-sm-12 col-md-offset-2 col-sm-offset-0">
                   <a href="<?php echo site_url('add_loan'); ?>" class="btn btn-default">
                       <i class="glyphicon glyphicon-chevron-left"></i> Back 
                   </a> 
                    <button type="submit" class="btn btn-primary" name="post">
                        <i class="glyphicon glyphicon-floppy-save"></i> Save
                    </button>                  
              </div>
          </div>
    </div><!--/ Panel Footer -->       
</div><!--/ Panel -->
<?php echo form_close(); ?>  
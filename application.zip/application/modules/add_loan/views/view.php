<div class="row">
	<div class="col-lg-12 col-md-12">		
		<?php 
                
                echo create_breadcrumb();		
                echo $this->session->flashdata('notify');
                
                ?>
	</div>
</div><!-- /.row -->

<section class="panel panel-default">
    <header class="panel-heading">
        <div class="row">
            <div class="col-md-8 col-xs-3">                
                <?php
                                  echo anchor(
                                           site_url('add_loan/add'),
                                            '<i class="glyphicon glyphicon-plus"></i>',
                                            'class="btn btn-success btn-sm" data-tooltip="tooltip" data-placement="top" title="Add Data"'
                                          );
                 ?>
                
            </div>
           
    </header>
    
    
    <div class="panel-body">
         <?php if ($add_loans) : ?>
          <table id="datatable" class="table table-hover table-condensed">
              
            <thead>
              <tr>
                <th class="header">#</th>
                
                    <th>Member</th>   
                
                    <th>Date</th>   
                
                    <th>Loan type</th>   
                
                    <th> Amount Borrowed</th>   
                
                    <th>Amount To Pay</th>   
                
                    <th>Paid</th>   
                
                    <th>Remaing</th>   
                
                    <th>Risk fund</th>   
                
                <th class="red header" align="right" width="120">Action</th>
              </tr>
            </thead>
            
            
            <tbody>
             
               <?php foreach ($add_loans as $add_loan) : ?>
              <tr>
              	<td><?php echo $number++;; ?> </td>
               
               <td><?php echo $add_loan['user']; ?></td>
               
               <td><?php echo $add_loan['date']; ?></td>
               
               <td><?php echo $add_loan['ltype']; ?></td>
               
               <td><?php echo $add_loan['borrowed']; ?></td>
               
               <td><?php echo $add_loan['amount_to_pay']; ?></td>
               
               <td><?php echo $add_loan['paid']; ?></td>
               
               <td><?php echo $add_loan['remaing']; ?></td>
               
               <td><?php echo $add_loan['riskfund']; ?></td>
               
                <td>    
                    
                    <?php
                                  echo anchor(
                                          site_url('add_loan/show/' . $add_loan['id']),
                                            '<i class="glyphicon glyphicon-eye-open"></i>',
                                            'class="btn btn-sm btn-info" data-tooltip="tooltip" data-placement="top" title="Detail"'
                                          );
                   ?>
                    
                    <?php
                                  echo anchor(
                                          site_url('add_loan/edit/' . $add_loan['id']),
                                            '<i class="glyphicon glyphicon-edit"></i>',
                                            'class="btn btn-sm btn-success" data-tooltip="tooltip" data-placement="top" title="Edit"'
                                          );
                   ?>
                   
                   <?php
                                  echo anchor(
                                          site_url('add_loan/destroy/' . $add_loan['id']),
                                            '<i class="glyphicon glyphicon-trash"></i>',
                                            'onclick="return confirm(\'Confirm Delete???\');" class="btn btn-sm btn-danger" data-tooltip="tooltip" data-placement="top" title="Delete"'
                                          );
                   ?>   
                                 
                </td>
              </tr>     
               <?php endforeach; ?>
            </tbody>
          </table>
          <?php else: ?>
                <?php  echo notify('Data not available','info');?>
          <?php endif; ?>
    </div>
    
    
    <div class="panel-footer">
        <div class="row">           
           <div class="col-md-9">
                 <?php echo $pagination; ?>
           </div>
        </div>
    </div>
</section>